title: 章鱼星球安装openwrt
date: '2023-01-09 20:21:01'
updated: '2023-05-22 13:18:07'
tags: [工控机, 软路由, openwrt]
permalink: /articles/2023/01/09/1673266861817.html
---
![image.png](https://bolo.bienao.life/image/20230111210015253.png)

# 介绍

　　章鱼星球，是一款基于区块链技术的高性能私人云盘，具有专业级安全性，超高速传输、容量无限扩展等特点。规格方面，8x1.5GHz八核高速处理器，2G DDR3内存超大缓存运行稳定，8G eMMC高速闪存云端存储，HDMI高清输出支持显示器直连，2个USB接口支持多种扩展，千兆网络接口，极致上传下载速度。

　　如果不会安装或者安装闲麻烦，可文章底部点击qq联系博主，可代装openwrt，手续费20呦，加青龙25，不过教程已经很详细了，自己动手试试吧:doge:

# 准备

1. 一个双USB头线数据线
2. 一个u盘(如果要跑青龙，至少准备个64G的u盘吧)
3. 一根网线
4. 一个12V2A或者1.5A的电源适配器（咸鱼买回来一般是没有的，可以先找买家问一下）
5. 安卓镜像：[点我下载](http://121.43.32.165:10025/d/2.%E7%B3%BB%E7%BB%9F%E9%95%9C%E5%83%8F/Openwrt/%E7%AB%A0%E9%B1%BC%E6%98%9F%E7%90%83/S912%E5%AE%89%E5%8D%93%E7%B2%BE%E7%AE%80%E7%BA%BF%E5%88%B7.img)
6. op镜像：[点我下载](http://121.43.32.165:10025/d/2.%E7%B3%BB%E7%BB%9F%E9%95%9C%E5%83%8F/Openwrt/%E7%AB%A0%E9%B1%BC%E6%98%9F%E7%90%83/openwrt_s912_zyxq_R22.7.7_k5.18.12-flippy-74%2B.7z)
7. 烧录工具：[点我下载](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E7%94%B5%E8%84%91/%E8%BD%AF%E8%B7%AF%E7%94%B1%E5%88%B7%E7%B3%BB%E7%BB%9F%E5%B7%A5%E5%85%B7/rufus-3.20.exe)
8. 线刷工具：[点我下载并安装](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E7%94%B5%E8%84%91/%E8%BD%AF%E8%B7%AF%E7%94%B1%E5%88%B7%E7%B3%BB%E7%BB%9F%E5%B7%A5%E5%85%B7/USB_Burning_Tool_v2.1.3.exe)

# 安装

### 1.线刷安卓系统

　　可以跳过线刷安卓系统，直接刷openwrt试试，如果打不开再刷安卓系统。

#### 1.1打开USB_Burning_Tool

![image.png](https://bolo.bienao.life/image/20230109193209835.png)

#### 1.2导入S912安卓精简线刷.img镜像

![image.png](https://bolo.bienao.life/image/20230109193251726.png)

#### 1.3导入中

![image.png](https://bolo.bienao.life/image/20230109193327270.png)

#### 1.4导入完成

![image.png](https://bolo.bienao.life/image/20230109193513169.png)

#### 1.5开始烧录

![image.png](https://bolo.bienao.life/image/20230109193559539.png)

#### 1.6插入电源

　　先将双USB头线数据线一头插在电脑上，用顶针之类的顶住reset按钮，在章鱼星球插入电源后，立即将另一头usb插在章鱼星球上（这顺序很重要，且时间把握很重要，不然USB_Burning_Tool一直识别不到章鱼星球），如果有进度条了则可以松口顶针。
![image.png](https://bolo.bienao.life/image/20230111192902958.png)

#### 1.7烧录成功，停止

![image.png](https://bolo.bienao.life/image/20230111193316317.png)

### 2.刷openwrt系统

#### 1.电脑插入u盘，并打开Rufus

![image.png](https://bolo.bienao.life/image/20230111193903542.png)

#### 2.选择openwrt镜像

![image.png](https://bolo.bienao.life/image/20230111194039250.png)

#### 3.点击开始

![image.png](https://bolo.bienao.life/image/20230111194155115.png)

#### 4.点击确定

![image.png](https://bolo.bienao.life/image/20230111194223974.png)

#### 5.刷好了

![image.png](https://bolo.bienao.life/image/20230111194531086.png)

### 3.查看局域网id

#### 3.1电脑连接光猫或者路由器

　　键盘按下win+r快捷键，打开运行窗口

![image.png](https://bolo.bienao.life/image/20230111200904271.png)

#### 3.2打开命令行

　　输入cmd，回车
![image.png](https://bolo.bienao.life/image/20230111201022372.png)

#### 3.3查看电脑ip

　　输入ipconfig，这个192.168.68.94就是电脑的局域网ip，192.168.68.1就是电脑的网关

![image.png](https://bolo.bienao.life/image/20230111201401797.png)

#### 3.4获取可用的ip

　　将电脑的ip的最后一位，加减一下，比如192.168.68.95或者192.168.68.93或者其他的，然后用ping命令ping一下，如果ping不通就是我们需要的ip

　　ping不通如下图，就这个就行

![image.png](https://bolo.bienao.life/image/20230111203805207.png)

　　ping通如下图，说明该ip已经被局域网内的其他设备占用，换一个ip再试

![image.png](https://bolo.bienao.life/image/20230111203925240.png)

### 3.打开openwrt

#### 3.1网线连接

　　用网线连接章鱼星球和电脑

#### 3.2启动章鱼星球

　　插上u盘后，用顶针之类的按住reset键，然后给设备通电，reset键按个3秒再放开，电脑浏览器输入192.168.1.1，如果打不开就重试。
![image.png](https://bolo.bienao.life/image/20230111195854768.png)

#### 3.3登陆openwrt

　　账号：root
　　密码：password
![image.png](https://bolo.bienao.life/image/20230111201932846.png)

#### 3.4设置静态ip

##### 3.4.1点击网络→接口→修改lan口

![image.png](https://bolo.bienao.life/image/20230111202116645.png)

##### 3.4.2修改ip，网关，dns

![image.png](https://bolo.bienao.life/image/20230111202425106.png)

　　ip：192.168.68.95（改成上面获取的局域网ip）
　　网关：192.168.68.1（改成上面获取的默认网关）
　　dns：223.5.5.5
　　下滑，点击保存&应用![image.png](https://bolo.bienao.life/image/20230111204420950.png)

#### 3.5重启章鱼星球

　　章鱼星球连上路由器或者光猫，确保电脑也是连的路由器或者光猫，浏览器输入上面的ip，我的就是192.168.68.95
![image.png](https://bolo.bienao.life/image/20230111205041546.png)

　　ok啦

