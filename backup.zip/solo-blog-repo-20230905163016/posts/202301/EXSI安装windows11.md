title: EXSI安装windows11
date: '2023-01-17 17:09:19'
updated: '2023-05-22 12:56:46'
tags: [EXSI, windows]
permalink: /articles/2023/01/17/1673958869067.html
---
# 准备

[点我下载镜像](http://121.43.32.165:10025/d/2.%E7%B3%BB%E7%BB%9F%E9%95%9C%E5%83%8F/Windows11/Windows.iso)

# 上传镜像

### 点击存储，点击数据存储浏览器

![image.png](https://bolo.bienao.life/image/20230117202535135.png)

### 新建目录

![image.png](https://bolo.bienao.life/image/20230117202632070.png)

### 上传

选择新建的目录，点击上传，选中刚刚下载的文件

![image.png](https://bolo.bienao.life/image/20230117202709290.png)

# 创建虚拟机

### 创建/注册虚拟机

![image.png](https://bolo.bienao.life/image/20230117191909303.png)

### 创建新虚拟机

![image.png](https://bolo.bienao.life/image/20230117191930864.png)

### 选择名称和客户机操作系统

名称：随便填
客户机操作系统系列：Windows
客户机操作系统版本：win 10（64位）

![image.png](https://bolo.bienao.life/image/20230117204117673.png)

### 选择存储

我这就一个固态硬盘，就默认这个

![image.png](https://bolo.bienao.life/image/20230117204646120.png)

### 自定义设置

CPU：自己看着配置
内存：自己看着配置
硬盘1：自己看着配置
CD/DVD 驱动器 1：选择数据存储ISO文件，选刚刚上传的Windows11镜像

![image.png](https://bolo.bienao.life/image/20230117211743913.png)

引导选项：BIOS

![image.png](https://bolo.bienao.life/image/20230117210915554.png)

### 完成

![image.png](https://bolo.bienao.life/image/20230117205922898.png)

# 安装

### 点击刚刚创建的虚拟机

![image.png](https://bolo.bienao.life/image/20230117210052618.png)

### 打开电源

![image.png](https://bolo.bienao.life/image/20230117210112089.png)

### 点击虚拟机显示器

![image.png](https://bolo.bienao.life/image/20230117210144792.png)

### 默认配置

![image.png](https://bolo.bienao.life/image/20230117211149406.png)

### 现在安装

![image.png](https://bolo.bienao.life/image/20230117211212771.png)

### 激活 Windows

![image.png](https://bolo.bienao.life/image/20230117211324820.png)

### 选择操作系统

![image.png](https://bolo.bienao.life/image/20230117213047450.png)

![image.png](https://bolo.bienao.life/image/20230117213112362.png)

### 选择自定义安装

![image.png](https://bolo.bienao.life/image/20230117213431482.png)

![image.png](https://bolo.bienao.life/image/20230117213456617.png)

![image.png](https://bolo.bienao.life/image/20230117213556206.png)

# windows设置

### 初始化配置

基本默认是就行了，我就不截图了

### 点击网络设置

![image.png](https://bolo.bienao.life/image/20230117220159963.png)

### 点击以太网

![image.png](https://bolo.bienao.life/image/20230117220806934.png)

### ip分配

可以看一下，下面自动分配的的IPv4的地址是多少，等会可以就设置这个ip

![image.png](https://bolo.bienao.life/image/20230117221037434.png)

### 设置静态ip

手动
IPv4：开
IP地址：可以参考你自己上面自动分配的ip地址
子网掩码：255.255.255.0
网关：填你自己局域网的网关
首选DNS：223.5.5.5

![image.png](https://bolo.bienao.life/image/20230117221503827.png)

### 设置远程桌面

![image.png](https://bolo.bienao.life/image/20230117222120031.png)

![image.png](https://bolo.bienao.life/image/20230117222341347.png)

### 本地远程连接

##### 打开远程桌面连接

![image.png](https://bolo.bienao.life/image/20230117222916789.png)

##### 输入ip:端口

ip：上面设置的ip
端口：3389

![image.png](https://bolo.bienao.life/image/20230117223034877.png)

##### 登陆

![image.png](https://bolo.bienao.life/image/20230117223425270.png)

![image.png](https://bolo.bienao.life/image/20230117223500387.png)

![image.png](https://bolo.bienao.life/image/20230117223720133.png)

这样就可以很方便的复制粘贴了😋

