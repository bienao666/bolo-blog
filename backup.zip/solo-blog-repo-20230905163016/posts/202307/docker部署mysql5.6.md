title: docker部署mysql:5.6
date: '2023-07-03 23:23:00'
updated: '2023-08-30 10:35:52'
tags: [mysql, docker]
permalink: /articles/2023/07/03/1688397828249.html
---
## 安装

```
docker run -p 3306:3306 --name mysql --restart=always --privileged=true \
-v /root/mysql/log:/var/log/mysql \
-v /root/mysql/data:/var/lib/mysql \
-v /root/mysql/conf:/etc/mysql \
-v /etc/localtime:/etc/localtime:ro \
-e TZ=Asia/Shanghai -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.6
```

## 参数说明

参数说明
-p 3306:3306：指定宿主机端口与容器端口映射关系
--name mysql：创建的容器名称
--restart=always：总是跟随docker启动
--privileged=true：获取宿主机root权限
-v /root/mysql/log:/var/log/mysql：映射日志目录，宿主机:容器
-v /root/mysql/data:/var/lib/mysql：映射数据目录，宿主机:容器
-v /root/mysql/conf:/etc/mysql ：映射配置目录，宿主机:容器
-v /etc/localtime:/etc/localtime:ro ：让容器的时钟与宿主机时钟同步，避免时区的问题，ro是read only的意思，就是只读。
-e MYSQL_ROOT_PASSWORD=123456：指定mysql环境变量，root用户的密码为123456
-d mysql:5.6：后台运行mysql容器，版本是5.6。

## 修改连接权限

1. docker进入mysql服务器

```
docker exec -it msyql /bin/bash
```

2. 修改mysql的访问权限

```
# 链接数据库
mysql -u root -p

# 输入密码

# 查看数据库
show databases;

# 使用mysql数据库
use mysql;

# 查看用户连接情况
select host, user, plugin,  authentication_string, password_expired from user;
```

3. 修改密码链接方式

```
# 允许远程链接修改密码
# ALTER USER root@'%' IDENTIFIED WITH mysql_native_password BY '123456';

# 修改密码链接方式 
ALTER USER root@'localhost' IDENTIFIED WITH mysql_native_password BY '123456';

# 修改访问权限，远程可连接
update user set user.Host='%' where user.User='root';

# 刷新权限
FLUSH PRIVILEGES;

# 退出
exist
```

