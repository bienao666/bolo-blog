title: springboot 整合 minio 对象存储服务器
date: '2023-07-26 16:49:00'
updated: '2023-08-10 15:54:57'
tags: [minio]
permalink: /articles/2023/07/26/1690361387859.html
---
# 1.前言

minio是对象存储服务。它基于Apache License 开源协议，兼容Amazon S3云存储接口。适合存储非结构化数据，如图片，音频，视频，日志等。对象文件最大可以达到5TB。

优点有高性能，可扩展，操作简单，有图形化操作界面，读写性能优异等。

# 2.安装

## 21.1 安装docker

```
yum -y install docker
```

```
systemctl start docker
```

```
systemctl enable docker
```

## 2.2 安装minio

```
#创建根目录minio
mkdir -p /usr/local/minio/data
```

```
docker run -d -p 9000:9000 -p 9001:9001 \
     --name minio \
     -d --restart=always \
     -e "MINIO_ACCESS_KEY=minioadmin" \
     -e "MINIO_SECRET_KEY=minioadmin" \
     -v /usr/local/minio/data:/data \
     minio server /data \
     --console-address ":9001"
```

**解析**

```
-d ：后台启动
-p ：端口映射
--name : 为这个容器取一个名字
-e ：设置环境变量
-v : 文件挂载
--restart=always : 参数能够使我们在重启docker时，自动启动相关容器
-e "MINIO_ACCESS_KEY=minioadmin" -e "MINIO_SECRET_KEY=minioadmin" : 设置用户名和登录密码
-v /usr/local/minio/data:/data -v /usr/local/minio/config:/root/.minio : 对存放配置和文件的目录挂载
minio server /data ： minio的启动命令,（minio 是镜像名字、 /data:数据存储位置）
```

# 3.配置

```
http://ip1:9001
```

账号：`minioadmin`

密码：`minioadmin`

![image.png](https://bolo.bienao.life/image/20230726164732877.png)

## 3.1 创建秘钥

![image.png](https://bolo.bienao.life/image/20230726160153728.png)

![image.png](https://bolo.bienao.life/image/20230726160217568.png)

**注意保存下方秘钥，只显示一次**

![image.png](https://bolo.bienao.life/image/20230726160400792.png)

## 3.2 创建存储桶

![image.png](https://bolo.bienao.life/image/20230726160433561.png)

![image.png](https://bolo.bienao.life/image/20230726160500079.png)

## 3.3 放开访问策略

![image.png](https://bolo.bienao.life/image/20230726160538739.png)

![image.png](https://bolo.bienao.life/image/20230726160609311.png)

# 4.整合

## 4.1 添加pom依赖

```
<dependency>
        <groupId>io.minio</groupId>
        <artifactId>minio</artifactId>
        <version>8.4.3</version>
</dependency>
```

## 4.2 application.yml文件

```
# Minio配置
minio:
  server:
    url: http://ip:9000
    accessKey:  # 创建的秘钥
    secretKey:  # 创建的秘钥
    fileBucKetValue: airsmart # 创建的存储桶
```

## 4.3 minio配置

```
package cc.gtac.airsmart.common.config;

import lombok.Data;

/**
 * @author tiandawei
 * @date 2023/7/26 10:14
 */
@Data
@Component
@ConfigurationProperties("minio.server")
public class MinIoProperties {

    /**
     * minio地址--url+端口号
     */
    private String url;

    /**
     * 账号
     */
    private String accessKey;

    /**
     * 密码
     */
    private String secretKey;

    /**
     * 桶名配置
     */
    private String fileBucKetValue;

}
```

## 4.4 minioclient

```
import cc.gtac.airsmart.common.config.MinIoProperties;
import cc.gtac.airsmart.common.utils.DateUtil;
import com.google.common.io.ByteStreams;
import io.minio.*;
import io.minio.errors.MinioException;
import io.minio.http.Method;
import io.minio.messages.Item;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author tiandawei
 * @date 2023/7/26 10:14
 */
@Slf4j
@Component
public class MinIoClient {

    private String url;

    private String accessKey;

    private String secretKey;

    public String fileBucKetValue;

    private static MinioClient minioClient;

    /**
     * 排序
     */
    public final static boolean SORT = true;

    /**
     * 不排序
     */
    public final static boolean NOT_SORT = false;

    /**
     * 默认过期时间(分钟)
     */
    private final static Integer DEFAULT_EXPIRY = 60;

    public MinIoClient(MinIoProperties minIoProperties) {
        this.url = minIoProperties.getUrl();
        this.accessKey = minIoProperties.getAccessKey();
        this.secretKey = minIoProperties.getSecretKey();
        this.fileBucKetValue = minIoProperties.getFileBucKetValue();
    }

    public void afterPropertiesSet() throws Exception {
        log.info("url ====>{}", url);
        minioClient = MinioClient.builder().endpoint(url).credentials(accessKey, secretKey).build();
        //方便管理分片文件，则单独创建一个分片文件的存储桶

        if (!StringUtils.isEmpty(fileBucKetValue) && !isBucketExist(fileBucKetValue)) {
            createBucket(fileBucKetValue);
        }
//        if (!StringUtils.isEmpty(allowOriginFileBucKet) && !isBucketExist(allowOriginFileBucKet)) {
//            createBucket(allowOriginFileBucKet);
//        }
    }

    /**
     * 获得实例
     * @author ChenYongJia
     * @date 2021-9-26 09:33:18
     * @return io.minio.MinioClient
     */
    public MinioClient getInstance() throws Exception {

        if (minioClient == null) {
            synchronized (MinIoClient.class) {
                if (minioClient == null) {
                    afterPropertiesSet();
                }
            }
        }
        return minioClient;
    }

    /**
     * 存储桶是否存在
     *
     * @param bucketName 存储桶名称
     * @return true/false
     */
    public boolean isBucketExist(String bucketName) throws Exception {
        return getInstance().bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
    }

    /**
     * 上传对象到minio，目标位置和存储名称存在重复时会覆盖
     *
     * @param bucketName 目标桶
     * @param filePath   目标位置和存储名称，如 tempdir/123.txt
     * @param file
     */
    public void putObject(String bucketName, String filePath, File file) throws Exception {
        getInstance().putObject(
                PutObjectArgs.builder()
                        .bucket(bucketName)
                        .object(removeSlash(filePath))
                        .stream(new FileInputStream(file), file.length(), -1)
                        .build()
        );
    }

    /**
     * 桶内文件复制
     *
     * @param bucketName     目标桶
     * @param sourceFilePath 目标位置
     * @param targetFilePath 复制到
     */
    public boolean copyObject(String bucketName, String sourceFilePath, String targetFilePath) throws Exception {

        try {
            getInstance().copyObject(CopyObjectArgs.builder()
                    .bucket(bucketName)
                    .object(targetFilePath)
                    .source(CopySource
                            .builder()
                            .bucket(bucketName)
                            .object(sourceFilePath)
                            .build()
                    )
                    .build());
            return true;
        } catch (MinioException e) {
            System.out.println("Error occurred: " + e);
            return false;
        }

    }

    /**
     * 上传对象到minio，目标位置和存储名称存在重复时会覆盖
     *
     * @param bucketName 目标桶
     * @param filePath   目标位置和存储名称，如 tempdir/123.txt
     * @param file
     */
    public void putObject(String bucketName, String filePath, InputStream file, String contentType) throws Exception {
        getInstance().putObject(
                PutObjectArgs.builder()
                        .bucket(bucketName)
                        .object(removeSlash(filePath))
                        .stream(file, file.available(), -1)
                        .contentType(contentType)
                        .build()
        );
    }

    /**
     * 删除削减
     *
     * @param str 入参
     * @author ChenYongJia
     * @date 9:33 2021/9/26
     * @return * @return java.lang.String
     */
    private String removeSlash(String str) {
        if (str.substring(0, 1).equals("/")) {
            return str.substring(1);
        }
        return str;
    }

    /**
     * 从minio下载指定路径对象，目标位置和存储名称存在重复时会覆盖
     *
     * @param bucketName 目标桶
     * @param filePath   目标位置和存储名称，如 tempdir/123.txt
     */
    public byte[] getObject(String bucketName, String filePath) throws Exception {

        InputStream inputStream = null;
        try {
            inputStream = getInstance().getObject(
                    GetObjectArgs.builder()
                            .bucket(bucketName)
                            .object(removeSlash(filePath))
                            .build()
            );
        } catch (MinioException e) {
            System.out.println("Error occurred: " + e);
            return null;
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        {
            ByteStreams.copy(inputStream, outputStream);
            byte[] buffer = outputStream.toByteArray();
            return buffer;
        }
    }

    /**
     * 获取文件状态信息
     *
     * @param bucketName 目标桶
     * @param filePath   目标位置和存储名称，如 tempdir/123.txt
     */
    public StatObjectResponse statObject(String bucketName, String filePath) throws Exception {

        try {
            return getInstance().statObject(
                    StatObjectArgs.builder()
                            .bucket(bucketName)
                            .object(removeSlash(filePath))
                            .build()
            );
        } catch (MinioException e) {
            System.out.println("Error occurred: " + e);
            return null;
        }
    }

    /**
     * 移除文件
     *
     * @param bucketName 目标桶
     * @param filePath   目标位置和存储名称，如 tempdir/123.txt
     */
    public void removeObject(String bucketName, String filePath) throws Exception {
        getInstance().removeObject(
                RemoveObjectArgs.builder()
                        .bucket(bucketName)
                        .object(removeSlash(filePath))
                        .build()
        );
    }

    /**
     * 创建存储桶
     *
     * @param bucketName 存储桶名称
     * @return true/false
     */
    public boolean createBucket(String bucketName) throws Exception {
        getInstance().makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
        return true;
    }

    /**
     * 获取访问对象的外链地址
     *
     * @param objectName 对象名称
     * @param expiry     过期时间(分钟) 最大为7天 超过7天则默认最大值
     * @return viewUrl
     */
    public String getOriginalObjectUrl(String objectName, Integer expiry) throws Exception {
        return getObjectUrl(fileBucKetValue, objectName, expiry);
    }

    /**
     * 获取访问对象的外链地址
     *
     * @param bucketName 存储桶名称
     * @param objectName 对象名称
     * @param expiry     过期时间(分钟) 最大为7天 超过7天则默认最大值
     * @return viewUrl
     */
    public String getObjectUrl(String bucketName, String objectName, Integer expiry) throws Exception {
        expiry = expiryHandle(expiry);
        return getInstance().getPresignedObjectUrl(
                GetPresignedObjectUrlArgs.builder()
                        .method(Method.GET)
                        .bucket(bucketName)
                        .object(removeSlash(objectName))
                        .expiry(expiry)
                        .build()
        );
    }

    /**
     * 创建上传文件对象的外链
     *
     * @param bucketName 存储桶名称
     * @param objectName 欲上传文件对象的名称
     * @param expiry     过期时间(分钟) 最大为7天 超过7天则默认最大值
     * @return uploadUrl
     */
    public String createUploadUrl(String bucketName, String objectName, Integer expiry) throws Exception {
        expiry = expiryHandle(expiry);
        return getInstance().getPresignedObjectUrl(
                GetPresignedObjectUrlArgs.builder()
                        .method(Method.PUT)
                        .bucket(bucketName)
                        .object(removeSlash(objectName))
                        .expiry(expiry)
                        .build()
        );
    }

    /**
     * 创建上传文件对象的外链
     *
     * @param bucketName 存储桶名称
     * @param objectName 欲上传文件对象的名称
     * @return uploadUrl
     */
    public String createUploadUrl(String bucketName, String objectName) throws Exception {
        return createUploadUrl(bucketName, objectName, DEFAULT_EXPIRY);
    }

    /**
     * 获取对象文件名称列表
     *
     * @param bucketName 存储桶名称
     * @param prefix     对象名称前缀
     * @param sort       是否排序(升序)
     * @return objectNames
     */
    public List<String> listObjectNames(String bucketName, String prefix, Boolean sort) throws Exception {
        ListObjectsArgs listObjectsArgs;
        if (null == prefix) {
            listObjectsArgs = ListObjectsArgs.builder()
                    .bucket(bucketName)
                    .recursive(true)
                    .build();
        } else {
            listObjectsArgs = ListObjectsArgs.builder()
                    .bucket(bucketName)
                    .prefix(prefix)
                    .recursive(true)
                    .build();
        }
        Iterable<Result<Item>> chunks = getInstance().listObjects(listObjectsArgs);
        List<String> chunkPaths = new ArrayList<>();
        for (Result<Item> item : chunks) {
            chunkPaths.add(item.get().objectName());
        }
        if (sort) {
            return chunkPaths.stream().distinct().collect(Collectors.toList());
        }
        return chunkPaths;
    }

    /**
     * 获取对象文件名称列表
     *
     * @param bucketName 存储桶名称
     * @param prefix     对象名称前缀
     * @return objectNames
     */
    public List<String> listObjectNames(String bucketName, String prefix) throws Exception {
        return listObjectNames(bucketName, prefix, NOT_SORT);
    }

    /**
     * 上传
     *
     * @param file
     * @return
     * @throws Exception
     */
    public String upload(MultipartFile file) throws Exception {
        InputStream inputStream = file.getInputStream();
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
        return upload(inputStream, suffix, contentType);
    }

    /**
     * 删除
     *
     * @param filePath
     * @return
     */
    public void remove(String filePath) throws Exception {
        String savePath = filePath.replace(url + "/" + fileBucKetValue + "/", "");
        removeObject(fileBucKetValue, savePath);
    }

    /**
     * 直接上传
     *
     * @param inputStream 文件流
     * @param suffix      文件后缀
     * @return
     * @throws Exception
     */
    public String upload(InputStream inputStream, String suffix, String contentType) throws Exception {
        String uuid = UUID.randomUUID().toString();
        String savePath = getSavePath(uuid + "." + suffix);
        putObject(fileBucKetValue, savePath, inputStream, contentType);
        return url + "/" + fileBucKetValue + "/" + savePath;
    }

    private String getSavePath(String fileName) {
        String dayStr = DateUtil.formatDateTime(new Date());
        String days = dayStr.substring(0, dayStr.lastIndexOf(" "));
        String[] dayArr = days.split("-");

        String path = dayArr[0] + "/" + dayArr[1] + "/" + dayArr[2] + "/" + fileName;

        return path;
    }

    /**
     * 将分钟数转换为秒数
     *
     * @param expiry 过期时间(分钟数)
     * @return expiry
     */
    private int expiryHandle(Integer expiry) {
        expiry = expiry * 60;
        if (expiry > 604800) {
            return 604800;
        }
        return expiry;
    }

}
```

## 4.5 在启动类中注入

```
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }


    //注册minio
    @Bean
    public MinIoClient getMiIoUtils(MinIoProperties minIoProperties) {
        return new MinIoClient(minIoProperties);
    }

    @Bean
    @ConfigurationProperties("minio.server")
    public MinIoProperties minIoProperties() {
        return new MinIoProperties();
    }
}
```

## 4.6 demo

```
/**
 * @description demo
 * @author tiandawei
 * @date 2023-07-26
 */
@RestController
@RequestMapping(value = "/demo")
public class DemoController {

    @Autowired
    private MinIoClient minIoClient;

    @PostMapping("/uploadFile")
    public void uploadFile(MultipartFile file){
        try {
            String saveUrl = minIoClient.upload(file);
            System.out.println(saveUrl);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @PostMapping("/deleteFile")
    public void deleteFile(@RequestBody String filePath){
        try {
            minIoClient.remove(filePath);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
```

