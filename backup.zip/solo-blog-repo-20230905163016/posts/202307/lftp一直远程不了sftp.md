title: lftp一直远程不了sftp
date: '2023-07-03 23:23:00'
updated: '2023-07-05 11:10:14'
tags: [lftp]
permalink: /articles/2023/07/03/1688398354997.html
---
![](https://b3logfile.com/bing/20221221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 前言

今天在开发时候遇到使用lftp远程服务器的时一直连不上，测试在本机用lftp远程正常，防护墙也都关闭了，排查了很久。

# lftp使用

```
lftp -u "root","password" sftp://ip
```

通过上面命令远程时候一直重复connect操作，可以执行下方命令使用调试模式

```
lftp -d -u "root","password" sftp://ip
```

# 排查问题

在调试模式中发现这样一段报错
`The authenticity of host 'ip (ip)' can't be established`

这个的意思是：客户端（lftp或SSH客户端）首次遇到远程主机，并且没有将主机的公钥指纹存储在其known_hosts文件中。

# 解决办法

## 方案1

如果你**信任远程主机**并希望继续连接，你可以手动验证主机的真实性。你可以使用以下命令将主机的公钥指纹添加到known_hosts文件中（将ip替换为你自己的服务器ip）：

```
ssh-keyscan ip >> ~/.ssh/known_hosts
```

## 方案2

修改/etc/ssh/ssh_config文件的配置，以后则不会再出现此问题
需要使用root权限
最后面添加

```
StrictHostKeyChecking no
UserKnownHostsFile /dev/null
```



