title: Centos7安装docker
date: '2023-05-31 18:01:00'
updated: '2023-06-01 08:31:10'
tags: [centos, docker]
permalink: /articles/2023/05/31/1685520681135.html
---
![](https://b3logfile.com/bing/20190910.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 介绍

Docker 是一个开源的应用容器引擎，让开发者可以打包他们的应用以及依赖包到一个可移植的镜像中，然后发布到任何流行的 Linux或Windows操作系统的机器上，也可以实现虚拟化。容器是完全使用沙箱机制，相互之间不会有任何接口。

# 安装

```
yum install docker
```

```
systemctl start docker
```

```
systemctl enable docker
```

# 常用命令

## 基础命令

* 启动docker
  
  ```
  systemctl start docker
  ```
* 关闭docker
  
  ```
  systemctl stop docker
  ```
* 重启docker
  
  ```
  systemctl restart docker
  ```
* 设置docker开机自启动
  
  ```
  systemctl enable docker
  ```
* 查看docker运行状态
  
  ```
  systemctl status docker
  ```

## 镜像命令

* 查看docker镜像列表
  
  ```
  docker  images
  ```
* 单独搜索镜像
  
  ```
  docker  images  镜像名
  ```
* 拉取镜像 不加tag(版本号) 即拉取docker仓库中 该镜像的最新版本latest 加:tag 则是拉取指定版本
  
  ```
  docker pull 镜像名
  docker pull 镜像名:tag
  ```
* 删除没有用的镜像
  
  ```
  docker rmi -f 镜像名/镜像ID
  ```

## 容器命令

* 查看正在运行的容器
  
  ```
  docker  ps
  ```
* 查看所有容器包括正在运行和停掉的容器
  
  ```
  docker  ps  -a
  ```
* 运行一个容器
  
  ```
  # -it 表示 与容器进行交互式启动 -d 表示可后台运行容器 （守护式运行）  --name 给要运行的容器 起的名字  /bin/bash  交互路径
  docker run -it -d --name 要取的别名 镜像名:Tag /bin/bash
  ```
* 访问容器
  
  ```
  docker  exec -it 容器名/容器ID /bin/bash
  ```
* 退出容器
  
  ```
  exit
  ```
* 停止容器
  
  ```
  docker stop 容器名/容器ID
  ```
* 删除容器
  
  ```
  docker rm -f 容器名/容器ID
  ```

