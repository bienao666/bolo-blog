title: 一个优秀的vps一键网络重装脚本
date: '2023-05-31 22:01:00'
updated: '2023-06-02 21:52:21'
tags: [vps, 系统]
permalink: /articles/2023/05/31/1685542310585.html
---
![](https://b3logfile.com/bing/20210316.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 介绍

有时候，有些 vps 服务商会有一些限制，比如重装系统只有有限次免费机会，或者是需要隔一段时间才允许重装一次，甚至有些厂商部分系统安装会直接报错装不了，这个时候一键重装脚本就非常有必要了。

本文介绍一个优秀的 vps 一键网络重装脚本，该脚本支持各大主流操作系统，使用其进行网络重装非常方便。

# 下载并执行脚本

## 海外用户下载并执行

```
wget --no-check-certificate -qO ~/Network-Reinstall-System-Modify.sh 'https://cxthhhhh.com/CXT-Library/Network-Reinstall-System-Modify/Network-Reinstall-System-Modify.sh' && chmod a+x ~/Network-Reinstall-System-Modify.sh && bash ~/Network-Reinstall-System-Modify.sh
```

## 国内用户下载并执行

```
wget --no-check-certificate -qO ~/Network-Reinstall-System-Modify.sh 'https://caoxiaotian.com/CXT-Library/Network-Reinstall-System-Modify/Network-Reinstall-System-Modify.sh' && chmod a+x ~/Network-Reinstall-System-Modify.sh && bash ~/Network-Reinstall-System-Modify.sh
```

# 选择并等待安装

执行脚本后，应该能看到如下选择界面

![image.png](https://bolo.bienao.life/image/20230531100803531.png)

比如我想安装 ubuntu20，则选择 11

选择完成后系统就开始下载系统并安装了，如果没有报错的话，应该会看到

`启动 安装  Start Installation `

显示到这里 ssh 连接就断掉了，此时可以去 VNC 查看安装状态，安装完成后 vps 就可以正常使用了

# 修改密码并更新系统

重装为 linux 系统的默认 root 密码为 cxthhhhh.com，默认的固定密码直接使用很不安全，因此需要立即更改密码：

```
sudo passwd
```

# 其他更改

经测试一键重装后并不会配置 ipv6 网络，如果您需要 ipv6 网络，还需要进一步手动配置，系统上其它问题暂时没有发现，稳定使用是没什么问题的。

# 说明

在 dd 系统的时候，从 vnc 后台可能会看到长时间卡在 Starting up the partitioner，这个是正常现象，实际后台正在写入数据，耐心等待就可以了。

![image.png](https://bolo.bienao.life/image/20230531101127390.png)

