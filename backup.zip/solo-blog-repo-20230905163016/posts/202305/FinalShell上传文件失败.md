title: FinalShell上传文件失败
date: '2023-05-29 12:28:00'
updated: '2023-05-29 12:28:00'
tags: [FinalShell]
permalink: /articles/2023/05/29/1685349057713.html
---
# 问题

用FinalShell上传文件秒失败

![image.png](https://bolo.bienao.life/image/20230529042739283.png)

# 解决

主要是文件权限问题，切换到root用户，给当前文件夹授权

```
chmod -R 777 文件夹名称
```

