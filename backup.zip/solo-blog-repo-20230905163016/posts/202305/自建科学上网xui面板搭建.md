title: 自建科学上网，x-ui面板搭建
date: '2023-05-20 14:09:00'
updated: '2023-08-16 11:18:23'
tags: [科学上网]
permalink: /articles/2023/05/20/1684567411453.html
---
![image.png](https://bolo.bienao.life/image/20230520022941396.png)

# 介绍

使用`X-UI`面板搭建`vmess+ws+tls+web`或者`vless+ws+tls+web`的节点，这是目前最安全的搭建方式并且为了更进一步的安全，有些步骤甚至有点繁琐，这都是值得的，只有安全了才能实现省时省心非常适合想有自己专属稳定的节点又不太愿意折腾的朋友。

# 准备

## 服务器(vps)

racknerd是我买的比较多国外服务器，价格很亲民，[点我购买](https://my.racknerd.com/aff.php?aff=7148)，系统选择ubuntu-20.04

![image.png](https://bolo.bienao.life/image/20230519095850201.png)

## 域名

namesilo是我自己用的域名，[点我购买](https://www.namesilo.com/?rid=d7a2698ub)，你也可以白嫖Freenom的域名，[白嫖教程点我](https://bolo.bienao.life/articles/2023/04/08/1684426010107.html)

## 域名解析

这次我们示例用的域名是internet.bienaoccc.life，参考下方教程生成一个类似的

[点我查看教程](https://bolo.bienao.life/articles/2023/05/19/1684509051675.html)

# 搭建

## 更新软件源

```
apt update
```

![image.png](https://bolo.bienao.life/image/20230520020343858.png)

## 启用 BBR TCP 拥塞控制算法

```
echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
sysctl -p
```

![image.png](https://bolo.bienao.life/image/20230520020443830.png)

## 安装x-ui

```
bash <(curl -Ls https://raw.githubusercontent.com/vaxilu/x-ui/master/install.sh)
```

![image.png](https://bolo.bienao.life/image/20230520020803888.png)

![image.png](https://bolo.bienao.life/image/20230520020958728.png)

## 安装nginx

```
apt install nginx
```

![image.png](https://bolo.bienao.life/image/20230520021133912.png)

## 安装acme

```
curl https://get.acme.sh | sh
```

![image.png](https://bolo.bienao.life/image/20230520021231712.png)

## 添加软链接

```
ln -s  /root/.acme.sh/acme.sh /usr/local/bin/acme.sh
```

![image.png](https://bolo.bienao.life/image/20230520021314055.png)

## 切换CA机构

```
acme.sh --set-default-ca --server letsencrypt
```

![image.png](https://bolo.bienao.life/image/20230520021345785.png)

## 申请证书

你的域名记得替换一下，我这边就替换为internet.bienaoccc.life

```
acme.sh  --issue -d 你的域名 -k ec-256 --webroot  /var/www/html
```

![image.png](https://bolo.bienao.life/image/20230520021558435.png)

## 安装证书

你的域名记得替换一下，我这边就替换为internet.bienaoccc.life

```
acme.sh --install-cert -d 你的域名 --ecc --key-file       /etc/x-ui/server.key  --fullchain-file /etc/x-ui/server.crt --reloadcmd     "systemctl force-reload nginx"
```

![image.png](https://bolo.bienao.life/image/20230520021705708.png)

## x-ui

### 打开x-ui

域名:上面安装时候设置的端口，我的示例就是internet.bienaoccc.life:8899

![image.png](https://bolo.bienao.life/image/20230520022941396.png)

### 切换最新版本

![image.png](https://bolo.bienao.life/image/20230520023117685.png)

### 添加节点

备注：随便填
协议：vmess
监听IP：127.0.0.1
端口：自己设置，等会nginx配置要用
id：自动生成，不改，先保存下，等会nginx配置要用
传输：ws
路径：/+上面的id

![image.png](https://bolo.bienao.life/image/20230520023337354.png)

### 面板设置

面板监听IP：127.0.0.1
面板url根路径：自己随便设置个，但必须以 '/' 开头，以 '/' 结尾，先保存下，等会nginx配置要用

![image.png](https://bolo.bienao.life/image/20230520023859838.png)

## 寻找伪装站

谷歌搜索**`intext:登录 Cloudreve`**，随便找一个点击进去能正常打开就行

![image.png](https://bolo.bienao.life/image/20230520022127370.png)

![image.png](https://bolo.bienao.life/image/20230520022156697.png)

## 配置nginx

1. 打开配置文件

![image.png](https://bolo.bienao.life/image/20230520022256438.png)

2. 复制粘贴下方配置，并修改保存，记得保存

```
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    gzip on;

    server {
        listen 443 ssl;
        
        server_name nicename.co;  #你的域名
        ssl_certificate       /etc/x-ui/server.crt;  #证书位置
        ssl_certificate_key   /etc/x-ui/server.key; #私钥位置
        
        ssl_session_timeout 1d;
        ssl_session_cache shared:MozSSL:10m;
        ssl_session_tickets off;
        ssl_protocols    TLSv1.2 TLSv1.3;
        ssl_prefer_server_ciphers off;

        location / {
            proxy_pass https://bing.com; #伪装网址
            proxy_redirect off;
            proxy_ssl_server_name on;
            sub_filter_once off;
            sub_filter "bing.com" $server_name; #伪装网址
            proxy_set_header Host "bing.com"; #伪装网址
            proxy_set_header Referer $http_referer;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header User-Agent $http_user_agent;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto https;
            proxy_set_header Accept-Encoding "";
            proxy_set_header Accept-Language "zh-CN";
        }


        location /ray {   #创建节点时候的id
            proxy_redirect off;
            proxy_pass http://127.0.0.1:10000; #Xray端口
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
        
        location /xui {   #xui路径
            proxy_redirect off;
            proxy_pass http://127.0.0.1:8899;  #xui监听端口
            proxy_http_version 1.1;
            proxy_set_header Host $host;
        }
    }

    server {
        listen 80;
        location /.well-known/ {
               root /var/www/html;
            }
        location / {
                rewrite ^(.*)$ https://$host$1 permanent;
            }
    }
}
```

![image.png](https://bolo.bienao.life/image/20230520024645667.png)

### 重新加载nginx配置文件

每次修改nginx配置文件后必须使用 **systemctl reload nginx** 命令重新加载配置文件

![image.png](https://bolo.bienao.life/image/20230520024825401.png)

### 访问x-ui

访问地址就是域名/面板url根路径/xui，我示例就是internet.bienaoccc.life/bienaoadmin/xui

![image.png](https://bolo.bienao.life/image/20230520025217779.png)

如果直接访问域名就会跳转刚刚的伪装网站，尽可能的隐藏翻墙

![image.png](https://bolo.bienao.life/image/20230520025229319.png)

## 使用方法

### 复制节点

![image.png](https://bolo.bienao.life/image/20230520025416214.png)

### 设置节点

这里推荐用v2ray，修改很方便
地址：你的域名
端口：443
加密方式：zero
tls：tls

![image.png](https://bolo.bienao.life/image/20230520025633463.png)

### 测试

测试有速度，谷歌能正常打开

![image.png](https://bolo.bienao.life/image/20230520025825002.png)

![image.png](https://bolo.bienao.life/image/20230520030020308.png)

## CDN加速

刚刚测速发现速度比较慢，我们可以设置cdn进行加速

### 修改nginx配置

将上面的一个location配置复制到下面这个监听80的server里面，443的我试了加cdn节点用不了，有大佬知道的可以告诉我下，记得保存

![image.png](https://bolo.bienao.life/image/20230520035058609.png)

### 重启nginx

```
systemctl reload nginx
```

### 设置cdn，下面两个方法2选1就行

#### 1.cloudflare

1.1 开启cdn

![image.png](https://bolo.bienao.life/image/20230520030224389.png)

1.2 测试cdn是否生效

用ping你的域名发现ip不是你原服务器的ip的时候就想cdn代理生效了，大概5-30分钟

![image.png](https://bolo.bienao.life/image/20230520031436976.png)

1.3修改配置

端口：80
tls：空

![image.png](https://bolo.bienao.life/image/20230520042628226.png)

#### 2.自己搭建cdn

2.1搭建服务
[搭建教程](https://bolo.bienao.life/articles/2023/06/18/1687137191426.html)

2.2修改配置

地址：cdn域名
端口：断端口
伪装域名：你的真实域名
tls：空

![image.png](https://bolo.bienao.life/image/20230520042409863.png)

### 测试速度

可以看到速度比刚刚快了不少，而且也不用担心被封的问题，主要是买的一般的服务器，最便宜的那种，速度上不去，如果资金充足可以直接上`CN2 GIA`的服务器

![image.png](https://bolo.bienao.life/image/20230520035439883.png)

![image.png](https://bolo.bienao.life/image/20230520045338934.png)

### 其他加速方法

加中转之类的，这个基本要花钱买服务，加了中转，延迟和速度都能有较高的提升，这个以后再说了

## 多用户配置

### 新建一个节点

备注：随便填
协议：vmess
监听IP：127.0.0.1
端口：自己设置，不能和之前的节点相同，等会nginx配置要用
id：自动生成，不改，先保存下，等会nginx配置要用
传输：ws
路径：/+上面的id

![image.png](https://bolo.bienao.life/image/20230520030610140.png)

### 修改nginx配置

1. 打开配置文件

![image.png](https://bolo.bienao.life/image/20230520022256438.png)

2. 复制粘贴下方配置，并修改保存，记得保存

```
location /ray {   #创建节点时候的id
    proxy_redirect off;
    proxy_pass http://127.0.0.1:10000; #Xray端口
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}
```

![image.png](https://bolo.bienao.life/image/20230520030923856.png)

3.重启nginx

```
systemctl reload nginx
```

![image.png](https://bolo.bienao.life/image/20230520031054980.png)

### 使用方法

和上面一样操作，不要觉得这样很麻烦，等到节点被长城防火墙封了的话你就后悔了，就算这样也还是有可能会被封，但是如果加了cdn就不用担新了，或者走中转

