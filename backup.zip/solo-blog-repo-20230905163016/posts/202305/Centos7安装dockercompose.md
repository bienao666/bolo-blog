title: Centos7安装docker-compose
date: '2023-05-31 18:10:00'
updated: '2023-06-01 08:31:18'
tags: [centos, docker-compose]
permalink: /articles/2023/05/31/1685536922427.html
---
![](https://b3logfile.com/bing/20191209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 添加EPEL源

```
yum install -y epel-release
```

# 安装python-pip

```
yum install -y python-pip
```

# 安装docker-compose

```
pip install docker-compose
```

# 注意

如果安装过程中提示
Could not find a version that satisfies the requirement docker-compose (from versions: )
No matching distribution found for docker-compose
You are using pip version 8.1.2, however version 9.0.1 is available.
You should consider upgrading via the 'pip install --upgrade pip' command.

```
pip install --upgrade pip
```

如果还是不行，就先卸载pip，然后重装

```
yum remove python-pip
```

```
wget https://bootstrap.pypa.io/get-pip.py
python get-pip.py
python3 get-pip.py  #安装python3的pip
```

