title: Cloudflare域名托管
date: '2023-05-20 08:08:00'
updated: '2023-05-22 13:14:18'
tags: [域名]
permalink: /articles/2023/05/19/1684509051675.html
---
# 介绍

![image.png](https://bolo.bienao.life/image/20230519102552544.png)

# 准备

1. 邮箱
2. 域名
3. 服务器

# 注册

1. 注册cloudflare的免费账号非常的方便，注册时只需要输入email地址和密码（登录cloudflare的密码，非email密码）即可，不会像国内网站那样要你填写各种个人信息的，基本上不用担心隐私问题。[点我注册](https://dash.cloudflare.com/sign-up)
   
   ![image.png](https://bolo.bienao.life/image/20230519101142856.png)
2. 邮箱验证
   
   ![image.png](https://bolo.bienao.life/image/20230519102155312.png)

# 添加站点

![image.png](https://bolo.bienao.life/image/20230519103330001.png)

## 输入域名

![image.png](https://bolo.bienao.life/image/20230519114052056.png)

![image.png](https://bolo.bienao.life/image/20230519103211199.png)

## 添加记录

名称自己填
ipv4填你服务器的ip
关闭代理(小云朵)

![image.png](https://bolo.bienao.life/image/20230519130423149.png)

## 更改域名服务器

我以namesilo域名商做示例，其他域名类似

### 点击DNS设置

![image.png](https://bolo.bienao.life/image/20230519115620184.png)

### 删除原设置

![image.png](https://bolo.bienao.life/image/20230519115727311.png)

### 复制cloudflare的DNS设置

![image.png](https://bolo.bienao.life/image/20230519115800095.png)

### 更改DNS设置

![image.png](https://bolo.bienao.life/image/20230519115850168.png)

### 等待域名服务器生效

域名下面出现绿色的√就是生效了，时间比较久，一般等1-15分钟生效，生效后会有邮件通知，可以先去搭建服务

![image.png](https://bolo.bienao.life/image/20230519120541536.png)

![image.png](https://bolo.bienao.life/image/20230519121848886.png)

## 测试

域名解析一般1-15分钟

1. 电脑快捷键win+R，打开运行窗口，输入cmd，确定

![image.png](https://bolo.bienao.life/image/20230519114807425.png)

2. 输入命令，如果能显示ip则解析成功
   域名 = 上面设置的名称.二级域名
   以我的上面的演示域名就是bolo.bienaoccc.life
   ```
   ping 域名
   ```

![image.png](https://bolo.bienao.life/image/20230519130334473.png)

