title: Idea热部署-JRebel
date: '2023-08-14 13:37:00'
updated: '2023-08-14 15:08:48'
tags: [Idea, JRebel]
permalink: /articles/2023/08/14/1691991499847.html
---
# 前言

JRebel是一款JVM插件，它使得Java代码修改后不用重启系统，立即生效。IDEA上原生是不支持热部署的，一般更新了 Java 文件后要手动重启 Tomcat 服务器，才能生效，浪费时间浪费生命。目前对于idea热部署最好的解决方案就是安装JRebel插件。

# 安装

## 安装插件

**JRebel**

![image.png](https://bolo.bienao.life/image/20230814131559036.png)

## 下载注册服务

[点我下载](https://cn-beijing-data.aliyundrive.net/5fb614bb88559d8879fa4ece860050dbfe258b5e%2F5fb614bbe390801bfdff41498f0449943b3a5c2a?di=bj29&dr=305635630&f=64d9b756a09e54c5dc86420c9cfad799027240db&response-content-disposition=attachment%3B%20filename%2A%3DUTF-8%27%27ReverseProxy_windows_amd64.exe&security-token=CAIS%2BgF1q6Ft5B2yfSjIr5beIs%2FEhOpF%2BqyEdlKApUEBZ8JihKHAuDz2IHFPeHJrBeAYt%2FoxmW1X5vwSlq5rR4QAXlDfNTKaYSygqFHPWZHInuDox55m4cTXNAr%2BIhr%2F29CoEIedZdjBe%2FCrRknZnytou9XTfimjWFrXWv%2Fgy%2BQQDLItUxK%2FcCBNCfpPOwJms7V6D3bKMuu3OROY6Qi5TmgQ41Uh1jgjtPzkkpfFtkGF1GeXkLFF%2B97DRbG%2FdNRpMZtFVNO44fd7bKKp0lQLukMWr%2Fwq3PIdp2ma447NWQlLnzyCMvvJ9OVDFyN0aKEnH7J%2Bq%2FzxhTPrMnpkSlacGoABfycOsOUH2xFg%2B0tuCgFjZBK%2BO7NY4CfBWR1epY8IQc0ns6TAdWU9SPCtQenZSbQe2XTA7tlJZCGOyPT7hrLZiDXv3joilNxvzIZ89kKFOsGQgSS1uCOP04a7mmPVhe987PqYPyegw8HqFKHj%2B1bxVbf%2FAOQCmEhQ8VM9C27Jj60%3D&u=dce80d38515846708e0cf2ed01190e1f&x-oss-access-key-id=STS.NUkiupi5dMnott1AATkMNkdkZ&x-oss-expires=1692010811&x-oss-signature=pWr3XQc8daE%2BUAYnk8y%2BYveNc6ZvT0ulL5NsAuEoXTw%3D&x-oss-signature-version=OSS2)，双击启动

![image.png](https://bolo.bienao.life/image/20230814131530639.png)

## 激活插件

1. 注册地址：`http://127.0.0.1:8888/{GUID}`，GUID可以使用[在线GUID地址](https://www.guidgen.com/)在线生成，然后替换{GUID}就行。
2. 邮箱地址随便填
3. 勾选同意，提交

![image.png](https://bolo.bienao.life/image/20230814132140727.png)

![image.png](https://bolo.bienao.life/image/20230814132156779.png)

## 离线工作模式

![image.png](https://bolo.bienao.life/image/20230814132304523.png)

![image.png](https://bolo.bienao.life/image/20230814132341878.png)

## 设置自动编译

要想实现热部署，首先需要对Intellij按如下进行设置：

1. 由于JRebel是实时监控class文件的变化来实现热部署的，所以在idea环境下需要打开自动变异功能才能实现随时修改，随时生效。

![image.png](https://bolo.bienao.life/image/20230814132528137.png)

2. 打开运行时编译，能找到compiler.automake.allow.when.app.running就设置下，没有就算了，重启idea
   Mac: SHIFT + COMMAND + A
   Windows: CTRL + ALT + SHIFT + /

![image.png](https://bolo.bienao.life/image/20230814133642960.png)

![image.png](https://bolo.bienao.life/image/20230814133657227.png)

## 注意

！！！一定要用JRebel模式启动！！！

