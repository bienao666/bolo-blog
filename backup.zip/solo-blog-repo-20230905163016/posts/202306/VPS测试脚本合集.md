title: VPS测试脚本合集
date: '2023-06-04 10:43:00'
updated: '2023-06-04 10:43:00'
tags: [vps, 脚本]
permalink: /articles/2023/06/03/1685847220001.html
---
![](https://b3logfile.com/bing/20221024.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 测试CPU性能脚本

```
apt update -y && apt install -y curl wget sudo
curl -sL yabs.sh | bash -s — -i -5
```

![image.png](https://bolo.bienao.life/image/20230603224526015.png)

# 解锁状态查看

```
bash <(curl -Ls https://cdn.jsdelivr.net/gh/missuo/OpenAI-Checker/openai.sh)
```

![image.png](https://bolo.bienao.life/image/20230603224558108.png)

# 流媒体状态查看

```
bash <(curl -L -s https://raw.githubusercontent.com/lmc999/RegionRestrictionCheck/main/check.sh)
```

![image.png](https://bolo.bienao.life/image/20230603225110397.png)

# 三网回程延迟测试

```
wget -qO- git.io/besttrace | bash
```

![image.png](https://bolo.bienao.life/image/20230603225140134.png)

# 三网回程测试

```
curl https://raw.githubusercontent.com/zhucaidan/mtr_trace/main/mtr_trace.sh|bash
```

![image.png](https://bolo.bienao.life/image/20230603225214675.png)

# 三网测速

```
bash <(curl -Lso- https://git.io/superspeed_uxh)
```

![image.png](https://bolo.bienao.life/image/20230603225247838.png)

# 测速命令

```
wget -qO- bench.sh | bash
```

![image.png](https://bolo.bienao.life/image/20230603225320581.png)

