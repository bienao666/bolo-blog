title: V2board搭建
date: '2023-06-04 19:08:00'
updated: '2023-06-04 19:58:31'
tags: [科学上网]
permalink: /articles/2023/06/03/1685873290290.html
---
![image.png](https://bolo.bienao.life/image/20230604044630176.png)

# V2board

V2board是一个开源且易于管理V2Ray程序的可视化用户管理系统，集成了web网站前端+后端多个v2ray节点+多用户管理+支付+邮件系统，支持TCP、WS+CDN、WS+TLS等协议，前端面板简洁易用。我这里采用的是aaPanel面板（宝塔国际版）部署，机器配置要求最低1核512M内存，建议选择1G内存及以上服务器。这篇教程主要记录下搭建使用V2board的方法，主要分为：面板搭建、节点对接、支付对接、邮件对接等教程。

搭建注意：该教程仅自用方便笔记 和 面向对电脑/服务器知识有一点基础的用户，同时v2board程序作者在不断优化更新，本教程跟新版本可能存在一定差异性，请注意不要完全照搬，当然偶尔我也会把本教程其中一些问题修改，实在搞不定的可以联系我。

# 演示

[环球世界](https://airport.bienao.life)

# 准备

## 服务器(vps)

至少需要两条服务器，一台搭建V2board，一台搭建节点，当然你也可以用一台

* 国外服务器(centos7.9)（[购买参考](https://bolo.bienao.life/articles/2023/06/02/1685709926440.html)，！！！只能国外服务器！！！）

## 域名

namesilo是我自己用的域名，[点我购买](https://www.namesilo.com/?rid=d7a2698ub)

## 域名解析

此次示例域名：airport.bienaoccc.life

[点我查看教程](https://bolo.bienao.life/articles/2023/05/19/1684509051675.html)

# 搭建

## 安装aaPanel(宝塔)

### 命令安装

#### 国外安装

```
yum install -y wget && wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh && bash install.sh
```

#### 国内安装

```
yum install -y wget && wget -O install.sh https://download.bt.cn/install/install_6.0.sh && sh install.sh ed8484bec
```

记得保存一下宝塔面板地址，账号，密码

![image.png](https://bolo.bienao.life/image/20230519131939465.png)

### 打开宝塔面板

![image.png](https://bolo.bienao.life/image/20230519132427963.png)

![image.png](https://bolo.bienao.life/image/20230519132503147.png)

![image.png](https://bolo.bienao.life/image/20230519132520501.png)

### 安装环境

☑️ Nginx 1.17
☑️ MySQL 5.6
☑️ PHP 7.4

安装速度与服务器的配置有关，配置越高安装的越快。

![image.png](https://bolo.bienao.life/image/20230604050154771.png)

![image.png](https://bolo.bienao.life/image/20230604050605868.png)

### 配置PHP

#### 安装扩展

![image.png](https://bolo.bienao.life/image/20230604051852041.png)

![image.png](https://bolo.bienao.life/image/20230604051926544.png)

#### 解除被禁止的函数

`putenv` `proc_open` `pcntl_alarm` `pcntl_signal`

![image.png](https://bolo.bienao.life/image/20230604052058015.png)

## 添加站点

### 新建站点

Domain name：上面的域名
Description：随便写
Website Path：站点目录
Database：Mysql
Database settings：自己设置
Password：自己设置

![image.png](https://bolo.bienao.life/image/20230604052528727.png)

### 删除原有文件

```
# 上面的Website Path
cd /www/wwwroot/airport
# 删除目录下文件
chattr -i .user.ini && rm -rf .htaccess 404.html index.html .user.ini
```

![image.png](https://bolo.bienao.life/image/20230604053427196.png)

### 拉取源码

```
git clone https://github.com/v2board/v2board.git ./
```

![image.png](https://bolo.bienao.life/image/20230604053656642.png)

### 安装

```
sh init.sh
```

数据库地址：默认就行，直接回车
数据库名：上面创建站点设置的
数据库用户名：上面创建站点设置的
数据库密码：上面创建站点设置的
管理员邮箱：自己设置

保存一下最后的地址，邮箱，密码，等会要用

![image.png](https://bolo.bienao.life/image/20230604054111079.png)

### 配置站点目录

![image.png](https://bolo.bienao.life/image/20230604054521563.png)

### 配置伪静态

```
location /downloads {
}

location / {  
    try_files $uri $uri/ /index.php$is_args$query_string;  
}

location ~ .*\.(js|css)?$
{
    expires      1h;
    error_log off;
    access_log /dev/null; 
}
```

![image.png](https://bolo.bienao.life/image/20230604054634071.png)

### 配置SSL

![image.png](https://bolo.bienao.life/image/20230604060129296.png)

### 配置定时任务

Type of Task：Shell Script
Name of Task： v2board
Period：N Minutes 1 Minute
Script content：php /www/wwwroot/路径/artisan schedule:run

![image.png](https://bolo.bienao.life/image/20230604054911082.png)

### 启动队列服务

#### 安装Supervisor

![image.png](https://bolo.bienao.life/image/20230604055124052.png)

#### 配置Supervisor

Name：V2board
Run User：www
Run Dir：站点目录
Start Command：php artisan horizon
Processes：1

![image.png](https://bolo.bienao.life/image/20230604055455222.png)

### 设置文件权限

```
chmod -R 777 站点目录
```

![image.png](https://bolo.bienao.life/image/20230604055753258.png)

## 访问V2board管理页面

地址：上面安装时候保存的

![image.png](https://bolo.bienao.life/image/20230604060617402.png)

![image.png](https://bolo.bienao.life/image/20230604060701426.png)

## 系统配置

### 站点配置

参考我的示例自己配置，重点订阅URL配置一定要配置

![image.png](https://bolo.bienao.life/image/20230604061113548.png)

### 安全配置

参考我的示例自己配置，后台路径修改后需要重新进一下后台

![image.png](https://bolo.bienao.life/image/20230604061444582.png)

### 订阅配置

参考我的示例自己配置

![image.png](https://bolo.bienao.life/image/20230604061713874.png)

### 节点配置

通讯秘钥可以随机生成个uuid，[uuid生成](https://www.hake.cc/tools/uuid)

![image.png](https://bolo.bienao.life/image/20230604062152803.png)

### 邮件配置

这里以谷歌邮箱示例

#### 开启POP

![image.png](https://bolo.bienao.life/image/20230604063142148.png)

![image.png](https://bolo.bienao.life/image/20230604063403998.png)

#### 开启两步验证

![image.png](https://bolo.bienao.life/image/20230604063605485.png)

![image.png](https://bolo.bienao.life/image/20230604063721290.png)

![image.png](https://bolo.bienao.life/image/20230604063734725.png)

![image.png](https://bolo.bienao.life/image/20230604063817375.png)

![image.png](https://bolo.bienao.life/image/20230604063842507.png)

#### 获取专用密码

![image.png](https://bolo.bienao.life/image/20230604063920154.png)

![image.png](https://bolo.bienao.life/image/20230604064000626.png)

![image.png](https://bolo.bienao.life/image/20230604064033213.png)

![image.png](https://bolo.bienao.life/image/20230604064102613.png)

#### 配置SMTP服务

SMTP服务器地址：smtp.gmail.com
SMTP服务端口：587
SMTP加密方式：tls
SMTP账号：邮箱账号
SMTP密码：上面获取的专用密码
发件地址：邮箱账号

![image.png](https://bolo.bienao.life/image/20230604064350539.png)

#### 重启Supervisor

![image.png](https://bolo.bienao.life/image/20230604064526808.png)

#### 邮件测试

![image.png](https://bolo.bienao.life/image/20230604064800150.png)

## 支付配置

这玩意毕竟是违法的，不可能傻傻的用自己的支付宝微信去收款，一般都是找三方支付，但是要找一个靠谱的三方支付挺难的，手续费不说，跑路是常有的，我这边就不推荐了，确定好三方支付后，获取三方支付的URL，PID，KEY配置下就好了。

![image.png](https://bolo.bienao.life/image/20230604065139217.png)

## 权限组管理

![image.png](https://bolo.bienao.life/image/20230604065910173.png)

## 节点管理

### 新建节点

我这里就以vmess节点做示例

![image.png](https://bolo.bienao.life/image/20230604065747999.png)

![image.png](https://bolo.bienao.life/image/20230604070217736.png)

```
{
  "path": "/自己看着填",
  "headers": {
    "Host": "节点域名"
  }
}
```

![image.png](https://bolo.bienao.life/image/20230604070334270.png)

![image.png](https://bolo.bienao.life/image/20230604070427468.png)

### 搭建节点

准备另一台服务器，并进行域名解析，

此次示例域名：node.bienaoccc.life

[点我查看教程](https://bolo.bienao.life/articles/2023/05/19/1684509051675.html)

#### 安装xrayr

```
bash <(curl -Ls https://raw.githubusercontent.com/XrayR-project/XrayR-release/master/install.sh)
```

![image.png](https://bolo.bienao.life/image/20230604070731269.png)

#### 配置xrayr

配置文件路径：/etc/XrayR/config.yml

![image.png](https://bolo.bienao.life/image/20230604071831433.png)

#### 重启xrayr

```
xrayr
```

![image.png](https://bolo.bienao.life/image/20230604072034704.png)

### 查看节点

可以看到是小黄点了，说明节点和机场之间是通了

![image.png](https://bolo.bienao.life/image/20230604072149199.png)

## 订阅管理

![image.png](https://bolo.bienao.life/image/20230604072324123.png)

![image.png](https://bolo.bienao.life/image/20230604072348095.png)

## 测试

### 充钱

先给我账号设置点钱，正常是走支付充值的或者直接购买，我这边就直接修改后台了

![image.png](https://bolo.bienao.life/image/20230604072649404.png)

### 获取订阅地址

直接访问域名就行，后台路径不用带，点击购买订阅

![image.png](https://bolo.bienao.life/image/20230604073015916.png)

![image.png](https://bolo.bienao.life/image/20230604073035761.png)

![image.png](https://bolo.bienao.life/image/20230604073053601.png)

![image.png](https://bolo.bienao.life/image/20230604073112586.png)

![image.png](https://bolo.bienao.life/image/20230604073157698.png)

### V2rayN测试

![image.png](https://bolo.bienao.life/image/20230604073406489.png)

![image.png](https://bolo.bienao.life/image/20230604073454141.png)

![image.png](https://bolo.bienao.life/image/20230604074323537.png)

可以看到延迟和速度都是正常的，使用没问题，如果测试不通可以看下防火墙是不是开着，如果开着关闭防火墙。

查询命令，查看得到“active（running）”，此时说明防火墙已经被打开了。

```
systemctl status firewalld.service
```

关闭防火墙

```
systemctl stop firewalld.service
```

永久关闭防火墙

```
systemctl disable firewalld.service
```

## 节点优化

当前节点是相当于我们是直接连接的服务器，很容易被封，现在基本上没有机场会使用直连，基本都是都是中转或者专线，这里讲下免费的cf的代理。

### 开启cf代理

![image.png](https://bolo.bienao.life/image/20230604074856448.png)

### 等待代理生效

只要这边解析出来的ip地址不是你服务器的地址，说明代理生效了

![image.png](https://bolo.bienao.life/image/20230604075341347.png)

### 测试

正常使用，没问题

![image.png](https://bolo.bienao.life/image/20230604075715283.png)

---

就先记这么多了，其他的后面再说

