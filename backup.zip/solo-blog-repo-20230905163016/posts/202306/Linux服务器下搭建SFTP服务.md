title: Linux服务器下搭建SFTP服务
date: '2023-06-26 22:41:00'
updated: '2023-07-03 17:46:36'
tags: [sftp]
permalink: /articles/2023/06/26/1687837316537.html
---
# 1.前言

SFTP是基于默认的22端口，是ssh内含的协议，只要启动了sshd就可以使用。sftp采用的是ssh加密隧道，安装性方面较ftp强，而且依赖的是系统自带的ssh服务

# 2.安装

### 2.0 创建组

```
groupadd sftp
```

### 2.1 创建一个用户sftpuser

```
useradd -g sftp -s /bin/false sftpuser
```

### 2.2 设置sftpuser用户的密码

```
passwd sftpuser
```

### 2.3 创建一个sftp的上传目录

```
mkdir -p /app/data
```

### 2.4 修改用户sftpuser所在的目录

```
usermod -d /app/data sftpuser
```

### 2.5 配置sshd_config

```
vim /etc/ssh/sshd_config
```

找到如下这行，并注释掉

```
#Subsystem sftp /usr/libexec/openssh/sftp-server
```

添加如下几行，如果添加之后出现问题，则添加到最后

```
Subsystem sftp internal-sftp  #指定使用sftp服务使用系统自带的internal-sftp 
Match user  sftpuser        #匹配用户，如果要匹配多个组，多个组之间用逗号分割
ChrootDirectory  /data/sftp   #设定属于用户组sftp的用户访问的根文件夹如设置    /data/sftp   作为sftpuser        的sftp根目录
ForceCommand internal-sftp #指定sftp命令,强制执行内部sftp，并忽略任何    ~/.ssh/rc文件中的命令
X11Forwarding no   #这两行，如果不希望该用户能使用端口转发的话就加    上，否则删掉
AllowTcpForwarding no
```

为什么用 internal-sftp 而不用默认的 sftp-server，这是因为：
这是一个进程内的 sftp 服务，当用户 ChrootDirectory 的时候，将不请求任何文件；更好的性能，不用为 sftp 再开一个进程。

### 2.6 设定Chroot目录权限

```
chown -R root:root /app/data
chmod 755 /app/data
```

### 2.7 建立SFTP用户登入后可写入的目录

```
mkdir /app/data/sftpuser
chown -R sftpuser:sftp /app/data/sftpuser/
chmod 755 /app/data/sftpuser/
```

### 2.8 重启sshd服务

```
service sshd restart
```

### 2.9 关闭SElinux

`SELINUX=disabled`

```
vim /etc/sysconfig/selinux
```

### 2.10 测试

```
sftp sftpuser@ip
```

