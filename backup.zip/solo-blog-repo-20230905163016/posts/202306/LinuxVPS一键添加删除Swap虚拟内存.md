title: Linux VPS一键添加/删除Swap虚拟内存
date: '2023-06-03 19:18:00'
updated: '2023-06-03 19:18:00'
tags: [linux]
permalink: /articles/2023/06/03/1685812634565.html
---
# 前言

很多人的`VPS`服务器由于内存太小，会导致很多进程被杀掉，这时候就需要我们添加`Swap`虚拟内存了，这里就整了个一键脚本方便懒人或小白使用。

# 脚本

**提示：** 脚本不支持`OpenVZ`架构，安装会自动退出。

运行命令：

```
wget https://www.quchao.net/dl/swap.sh && bash swap.sh
```

然后根据选项进行操作，记得添加`swap`的时候填写纯数字，默认单位为`M`。

![image.png](https://bolo.bienao.life/image/20230603131647029.png)



