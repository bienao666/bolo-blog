title: Mybatis 分页插件 Pagehelper 的 PageInfo 字段属性解释
date: '2023-06-28 19:16:00'
updated: '2023-06-28 19:16:00'
tags: [Pagehelper]
permalink: /articles/2023/06/28/1687951029339.html
---
# 前言

分页插件返回的属性有点多，自己梳理一下

# 属性列表

```
pageNum=1,当前页码
pageSize=1,每页个数
size=1,当前页个数
startRow=1,由第几条开始
endRow=1,到第几条结束
total=3,总条数
pages=3,总页数
list= XXXX 查出出来的数据集合
prePage=0,上一页
nextPage=2,下一页
isFirstPage=true,是否为首页
isLastPage=false,是否为尾页
hasPreviousPage=false,是否有上一页
hasNextPage=true,是否有下一页
navigatePages=8,每页显示的页码个数
navigateFirstPage=1,首页
navigateLastPage=3,尾页
navigatepageNums=[1, 2, 3]}页码数
```

