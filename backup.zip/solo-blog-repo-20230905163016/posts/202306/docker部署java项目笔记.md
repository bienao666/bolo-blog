title: docker部署java项目笔记
date: '2023-06-15 12:15:00'
updated: '2023-07-01 20:16:40'
tags: [技术]
permalink: /articles/2023/04/05/1686819169095.html
---
# 前言

# 准备

### 1.上传jar包

```
mkdir docker && cd docker && mkdir log && mkdir config
```

### 2.Dockerfile

```
vi Dockerfile
```

```
#依赖java8
FROM openjdk:8-alpine
#创建者
MAINTAINER bolo.bienao.life
#暴露8899，表示镜像将对外暴露8080端口，也就是编写项目时的运行端口。
#EXPOSE 8899
#挂载目录,表示将镜像的/file文件夹声明为匿名卷。这样做是因为，项目会读写文件系统的/file文件夹，如果不声明，那么项目运行后只会对镜像内的虚拟目录/file读写，而不会对主机的目录读写，等关闭容器后，写的内容就没了。所以，声明匿名卷是为了将写操作持久化。仅仅在dockerfile里声明还不够，在运行容器时还需要设置匿名卷对应的主机目录。
VOLUME /tmp
#表示将IPPreferred-0.0.1-SNAPSHOT.jar，也就是项目jar包，拷贝进镜像，并命名为IPPreferred.jar。如果不拷贝，镜像就没jar包可运行了。
ADD IPPreferred-0.0.1-SNAPSHOT.jar /app/IPPreferred.jar
#宿主机的jdk目录
ENV JAVA_HOME /usr/local/jdk/
ENV PATH $PATH:$JAVA_HOME/bin
#容器运行后执行的命令。这里就只需要运行jar包就行了。
ENTRYPOINT ["java","-jar","-Duser.timezone=GMT+08","/app/IPPreferred.jar","--spring.config.location=/app/config/application.yml"]
```

### 3. 制作容器

在 jar 包和 Dockerfile 所在的目录执行下列的命令，镜像名为 ippreferred，自行修改，注意最后有一个点

```
docker build -t 项目名 .
```

![image.png](https://bolo.bienao.life/image/20230615162314661.png)

### 4.登陆Docker

首先，你需要在[Docker Hub](https://www.docker.com)或者其他你想要上传的Docker注册表上创建一个账号

```
docker login
```

![image.png](https://bolo.bienao.life/image/20230615162809813.png)

### 5.添加标签

```
docker tag 项目名:latest 你的名称/项目名:latest
```

### 6.上传镜像

```
docker push 你的名称/项目名:latest
```

