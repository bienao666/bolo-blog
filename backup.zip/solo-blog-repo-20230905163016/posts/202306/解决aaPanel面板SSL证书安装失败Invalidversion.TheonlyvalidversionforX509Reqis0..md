title: 解决aaPanel面板SSL证书安装失败 Invalid version. The only valid version for X509Req is
  0.
date: '2023-06-03 13:01:00'
updated: '2023-06-03 13:01:00'
tags: [aaPanel]
permalink: /articles/2023/06/03/1685771281774.html
---
# 问题

aaPanel安装SSL报错：Invalid version. The only valid version for X509Req is 0.

![image.png](https://bolo.bienao.life/image/20230603013841057.png)

# 解决

通过宝塔面板的文件，找到文件目录：/www/server/panel/class下面的acme_v2.py文件。

X509Req.set_version(2)修改为X509Req.set_version(0)

![image.png](https://bolo.bienao.life/image/20230603014224223.png)

![image.png](https://bolo.bienao.life/image/20230603014501523.png)

# 重启

![image.png](https://bolo.bienao.life/image/20230603014730068.png)





