title: 苹果抓包神器Stream安装
date: '2023-06-05 12:39:00'
updated: '2023-06-05 23:27:59'
tags: [ios软件, 抓包]
permalink: /articles/2023/06/05/1685972402029.html
---
### 前言

有些人安装后抓包有问题，所以写了喂饭安装步骤，任何步骤都不能缺。

### AppStroe搜索Stream下载并安装打开

### 点击开始抓包，允许

![image.png](https://bolo.bienao.life/image/20230605092829960.png)

### 安装证书，需要输入下密码

![image.png](https://bolo.bienao.life/image/20230605093213577.png)

### 点击步骤一，安装CA证书

![image.png](https://bolo.bienao.life/image/20230605093249020.png)

### 点击允许，下载描述文件

![image.png](https://bolo.bienao.life/image/20230605093359951.png)

### 打开设置，通用，下滑打开VPN与设备管理

### 找到Stream开头的，点击，再点击右上角的安装，输入手机密码，点击安装

### 返回Stream，ios10.3+和ios11应该会弹出去信任证书，点击去信任证书

![image.png](https://bolo.bienao.life/image/20230605093541229.png)

### 打开设置，通用，关于本机，下滑证书信任设置，将Stream开头的打开

![image.png](https://bolo.bienao.life/image/20230605093817111.png)

