title: 'Root WebApplicationContext: initialization completed'
date: '2023-06-16 22:49:00'
updated: '2023-06-16 22:49:00'
tags: [技术]
permalink: /articles/2023/06/16/1686927773509.html
---
# 前言

在用docker部署java项目的时候发生了部署不上的情况，启动卡在Root WebApplicationContext: initialization completed in 2528 ms，如下图：

![image.png](https://bolo.bienao.life/image/20230616225319577.png)

# 原因

tomcat启动时要有一个SessionId ，这个SessionId是linux提供的(/dev/random)，这个linux提供的随机数的生成算法 根据I/O 内存使用、cpu使用等等算出来的，把这些个影响随机数生成的称为噪音(熵值)，当噪音不够时，随机数生成不了(阻塞)。随机数阻塞，tomcat sessionId阻塞，tomcat 阻塞，springboot阻塞，程序就卡在那，一动不动。

查看当前系统熵值

```
cat /proc/sys/kernel/random/entropy_avail
```

![image.png](https://bolo.bienao.life/image/20230616225458398.png)

# 解决

## 1.安装熵服务

```
yum install rng-tools
```

## 2.启动熵服务

```
systemctl start rngd
```

# PS

还不行的话重启一下服务器

```
reboot
```

