title: 服务器（vps）推荐
date: '2023-06-02 12:40:00'
updated: '2023-06-02 12:40:00'
tags: [服务器, vps]
permalink: /articles/2023/06/02/1685709926440.html
---
我推荐的这些都是我用过的，其他如果有性价比高的欢迎投稿

# 国内

## 阿里云 [点我购买](https://)

送福利！阿里云热门产品免费领（含ECS），[点击进入](https://free.aliyun.com/?crowd=personal&utm_content=m_1000370359&source=5176.11533457&userCode=u2nbz4yj)

![image.png](https://bolo.bienao.life/image/20230602082434498.png)

## 华为云 [点我购买](https://activity.huaweicloud.com/discount_area_v5/index.html?fromacct=c9c95e1b-ffc3-4a32-9785-afddfcb18a04&utm_source=aHdfMDA4NjE1MzcxOTMwMzc1XzAy=&utm_medium=cps&utm_campaign=201905)

送福利！华为云热门产品免费领（含ECS），[点击进入](https://activity.huaweicloud.com/free_test/index.html?fromacct=c9c95e1b-ffc3-4a32-9785-afddfcb18a04&utm_source=aHdfMDA4NjE1MzcxOTMwMzc1XzAy=&utm_medium=cps&utm_campaign=201905)

![image.png](https://bolo.bienao.life/image/20230602083056491.png)

## 腾讯云[点我购买](https://curl.qcloud.com/GduADfMf)

送福利！腾讯云热门产品免费领（含ECS），[点击进入](https://cloud.tencent.com/act/cps/redirect?redirect=10041&cps_key=65f57dcb1cdabc585a27d2ef4be34dd9)

![image.png](https://bolo.bienao.life/image/20230602083348813.png)

# 国外

## RackNerd [点我购买](https://my.racknerd.com/aff.php?aff=7148)

RackNerd是海外华人创立的VPS服务器商，已经稳定运作4年时间，国外VPS平台2021年度用户投票的TOP3商家。该商家主要特色：走便宜VPS路线、性价比高、售后响应速度迅速、机器线路对中国大陆有特别优化。因为这几个显著特点，所以也迅速占领了大陆市场，在中国用户群体中热度都比较高。商家官网有繁体中文版，并支持国内的支付宝，微信，以及国外主流的PayPal、信用卡等付款方式。

![image.png](https://bolo.bienao.life/image/20230602081553737.png)

## 热网互联 [点我购买](https://www.hotiis.com/?ref=9z2BsW0q)

热网互联成立于2016年， 随客云计算旗下平台。热网互联主要运营美国、香港、日
本、韩国、阿姆斯特丹（阿姆斯特丹目前已售罄）等机房，主打低价VPS，支持从1个月-1年的付款周期，季付更加优惠，商家支持微信、支付宝、paypal、银联的支付方式。

![image.png](https://bolo.bienao.life/image/20230602084153991.png)

