title: CentOS8 错误：为 repo AppStream下载元数据失败
date: '2023-06-30 10:24:00'
updated: '2023-08-04 17:32:46'
tags: [centos8, docker]
permalink: /articles/2023/06/30/1688092286928.html
---
# 1.前言

安装centos8后发现yum用不了
![image.png](https://bolo.bienao.life/image/20230630102554123.png)

原因：在2022年1月31日，CentOS团队终于从官方镜像中移除CentOS 8的所有包。
CentOS 8已于2021年12月31日寿终正非，但软件包仍在官方镜像上保留了一段时间。现在他们被转移到https://vault.centos.org

# 2.解决-换源

```
bash <(curl -sSL https://linuxmirrors.cn/main.sh)
```



