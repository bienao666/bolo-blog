title: Google Play
date: '2023-06-03 21:41:00'
updated: '2023-06-03 21:41:00'
tags: [安卓软件]
permalink: /articles/2023/06/03/1685810545220.html
---
对于一些出国人来讲，谷歌商店已经是他们的必需品。可惜，在大陆销售的手机，由于政策原因，厂商是不可能在上面安装 Google Play 商店的。那么在这篇文章中，我来和大家一起来在安卓设备上安装 Google Play 商店。

## 准备材料

* 安卓设备

## 下载安装

[点我下载](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E6%89%8B%E6%9C%BA/%E5%BA%94%E7%94%A8%E5%B8%82%E5%9C%BA/GooglePlay/Google%20Play.apk)

下载后直接安装，试用前提是手机先要科学上网呦，[科学上网点我](https://airport.bienao.life)

![image.png](https://bolo.bienao.life/image/20230603124128435.png)

![image.png](https://bolo.bienao.life/image/20230603123934632.png)

![image.png](https://bolo.bienao.life/image/20230603123957054.png)





