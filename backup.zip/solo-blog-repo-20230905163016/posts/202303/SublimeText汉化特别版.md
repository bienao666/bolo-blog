title: SublimeText 汉化特别版
date: '2023-03-16 13:04:00'
updated: '2023-05-22 13:00:03'
tags: [电脑软件, 编程软件]
permalink: /articles/2023/03/16/1678943079682.html
---
![image.png](https://bolo.bienao.life/image/20230316130715480.png)

Sublime Text 是一个轻量、简洁、高效、跨平台的编辑器，方便的配色以及兼容vim快捷键等各种优点博得了很多前端开发人员的喜爱!Sublime Text 这款程序员必备代码编辑器，几乎每位程序员提到Sublime Text 2都是赞不绝口！它体积小巧，无需安装，绿色便携；它可跨平台支持Windows/Mac/Linux；支持32与64位操作系统，它在支持语法高亮、代 码补全、代码片段（Snippet）、代码折叠、行号显示、自定义皮肤、配色方案等所有其它代码编辑器所拥有的功能的同时，又保证了其飞快的速度！还有着 自身独特的功能，比如代码地图、多种界面布局以及全屏免打扰模式等，这些优秀特性让Sublime Text 2成了所有程序员眼中的神！

SublimeText支持但不限于 C, C++, C#, CSS, D, Erlang, HTML, Groovy, Haskell, HTML, Java, JavaScript, LaTeX, Lisp, Lua, Markdown, Matlab, OCaml, Perl, PHP, Python, R, Ruby, SQL, TCL, Textile and XML 等主流编程语言的语法高亮。ST 拥有优秀的代码自动完成功能 (自动补齐括号，大括号等配对符号；自动补全已经出现的单词；自动补全函数名)，非常智能；

![image.png](https://bolo.bienao.life/image/20230316131205343.png)

## 修改说明

基于最新版本绿色便携制作

增强侧边栏

集成修改补丁，集成汉化，允许切换语言

## 更新日志

GPU 渲染
新的 hardware_acceleration 设置将在 GPU 上合成 UI
默认情况下，GPU 渲染在 Mac 上启用，在 Windows 和 Linux 上禁用
有关活动 GPU 的详细信息将显示在控制台中
上下文感知自动完成
自动完成引擎现在根据现有代码中的模式建议完成
使用整个项目作为源，而不仅仅是当前视图
插件可以指定要在建议列表中显示的符号种类信息
选项卡多选
可以使用 ctrl/cmd 选择多个选项卡，它们的内容将并排显示
从侧边栏中选择多个文件也将同时预览它们
使用工作表多选时，包含的主题有一个连接活动工作表和选项卡的选项卡连接器
侧边栏现在可以使用 alt 选择多个文件
Goto Anything 允许使用 ctrl/cmd 并排打开选项卡
定义弹出窗口有一个专用按钮，用于并排打开文件
也可以从选项卡下拉列表中选择多个选项卡
菜单选择/选项卡选择包含用于操作选项卡多选的各种选项
文件/新视图到文件已被使用多选的文件/拆分视图替换

## 下载地址

[点我下载](http://121.43.32.165:10025/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E7%94%B5%E8%84%91/%E7%BC%96%E7%A8%8B%E8%BD%AF%E4%BB%B6/SublimeText)

