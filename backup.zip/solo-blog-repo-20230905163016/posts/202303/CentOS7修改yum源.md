title: CentOS 7修改yum源
date: '2023-03-30 13:08:00'
updated: '2023-03-30 13:08:00'
tags: [centos]
permalink: /articles/2023/03/30/1684732127626.html
---
![](https://b3logfile.com/bing/20210324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 备份系统原 `yum` 源

```
mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.backup
```

### 替换 `yum` 源

* 华为 `yum` 源

```
wget -O /etc/yum.repos.d/CentOS-Base.repo https://repo.huaweicloud.com/repository/conf/CentOS-7-reg.repo
```

* 阿里 `yum` 源

```
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
```

* 网易163 `yum` 源

```
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.163.com/.help/CentOS7-Base-163.repo
```

### 替换 `EPEL` 源 - 可选

* 阿里 `EPEL` 源

```
wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
```

### 清理缓存

```
yum clean all
```

### 生成新的缓存

```
yum makecache
```

### 更新系统

```
yum -y update
```

