title: mailx结合QQ邮箱在Linux下发送系统邮件提醒等
date: '2023-04-02 13:11:00'
updated: '2023-05-22 13:09:52'
tags: [邮件]
permalink: /articles/2023/04/02/1684422957798.html
---
![](https://b3logfile.com/bing/20211114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 安装与配置mailx

> 系统环境：`CentOS Linux release 7.9.2009`，大部分系统默认集成mailx，最小化安装系统时，仍需安装mailx

* 执行以下命令安装 mailx

```
# yum install -y mailx
```

![image.png](https://bolo.bienao.life/image/20230518111335525.png)

### 编辑 `/etc/mail.rc` 文件

* `set from` 以及 `set smtp-auth-user` 填入自己的邮箱地址，`set smtp-auth-password` 填入授权码

```
# vim /etc/mail.rc

# 在文件末尾填入以下内容

set from=xxxxxx@qq.com
set smtp=smtps://smtp.qq.com:465
set smtp-auth-user=xxxxxx@qq.com
set smtp-auth-password=你的QQ邮箱授权码
set smtp-auth=login
set ssl-verify=ignore
set nss-config-dir=/root/.certs
```

* 授权码可到邮箱设置-->账户设置，开启 `POP3/SMTP服务` 时会生成邮箱授权码
  ![image.png](https://bolo.bienao.life/image/20230518111401148.png)

### 获取邮箱的SSL证书

* 依次执行以下命令

```
# mkdir -p /root/.certs/
# echo -n | openssl s_client -connect smtp.qq.com:465 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > ~/.certs/qq.crt
# certutil -A -n "GeoTrust SSL CA" -t "C,," -d ~/.certs -i ~/.certs/qq.crt
# certutil -A -n "GeoTrust Global CA" -t "C,," -d ~/.certs -i ~/.certs/qq.crt
# certutil -L -d /root/.certs
# cd /root/.certs
# certutil -A -n "GeoTrust SSL CA - G3" -t "Pu,Pu,Pu" -d ./ -i qq.crt
```

![image.png](https://bolo.bienao.life/image/20230518111440348.png)

* 当看到以下内容时，已完成mailx结合QQ邮箱发送系统邮件的部署

![image.png](https://bolo.bienao.life/image/20230518111502586.png)

### 测试

* 执行以下命令，`xxxxxx@qq.com` 修改为自己的邮箱，`Test` 为邮件标题，`发送测试内容邮件` 为邮件内容，按实际修改即可！

```
# echo -e "发送测试内容邮件"|mailx -v -s "Test" xxxxxx@qq.com
```

![image.png](https://bolo.bienao.life/image/20230518111547412.png)

