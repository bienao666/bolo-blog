title: Linux下监控Tomcat的状态并实现自动启动脚本
date: '2023-04-03 15:11:00'
updated: '2023-05-22 13:10:50'
tags: [linux]
permalink: /articles/2023/04/03/1684423366562.html
---
![](https://b3logfile.com/bing/20201207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 编写TomcatMonitor.sh脚本

> tomcat 路径等，页面地址均按实际修改

* 本站下载

```
wget http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E6%9C%8D%E5%8A%A1%E5%99%A8/linux/shell/TomcatMonitor.sh
```

* 或手动编辑

```
vim TomcatMonitor.sh
```

```
# 写入以下内容

#!/bin/bash

# 获取tomcat进程ID
TomcatID=$(ps -ef | grep tomcat | grep '/bin/java' | grep -v grep | awk '{print $2}')

# tomcat启动程序(这里注意tomcat实际安装的路径)
StartTomcat=/usr/local/tomcat/bin/startup.sh
TomcatCache=/usr/local/tomcat/work/*
TomcatTemp=/usr/local/tomcat/temp/*

#定义要监控的页面地址
WebUrl=http://192.68.10.20:8080

#日志输出
GetPageInfo=/usr/local/tomcat/logs/TomcatMonitor.Info
TomcatMonitorLog=/usr/local/tomcat/logs/TomcatMonitor.log

Monitor()
{
    echo "[info]开始监控tomcat...[$(date +'%F %H:%M:%S')]"
    if [ $TomcatID ];then #这里判断Tomcat进程是否存在
        echo "[info]当前tomcat进程ID为:$TomcatID,继续检测页面..."
        # 检测是否启动成功(成功的话页面会返回状态"200")
        TomcatServiceCode=$(curl -s -o $GetPageInfo -m 10 --connect-timeout 10 $WebUrl -w %{http_code})
        if [ $TomcatServiceCode -eq 200 ];then
            echo "[info]页面返回码为$TomcatServiceCode，tomcat启动成功，测试页面正常"
        else
            echo "[error]tomcat页面出错，请注意...状态码为$TomcatServiceCode，错误日志已输出到$GetPageInfo"
            echo "[error]页面访问出错，开始重启tomcat"
            kill -9 $TomcatID # 杀掉原tomcat进程
            sleep 3
            rm -rf $TomcatCache # 清理tomcat缓存
	    rm -rf $TomcatTemp
            $StartTomcat
        fi
    else    
        echo "[error]tomcat进程不存在!tomcat开始自动重启..."
        echo "[info]$StartTomcat，请稍候..."
        rm -rf $TomcatCache
	rm -rf $TomcatTemp
        $StartTomcat
    fi
    echo "--------------------------"
}
Monitor>>$TomcatMonitorLog
```

### 脚本授权

```
# chmod +x TomcatMonitor.sh
```

### 执行脚本

```
# ./TomcatMonitor.sh
```

### 设置定时任务

* 定时任务频率切勿过高，否则会造成系统无法访问等问题，一小时或每天执行一次即可！

```
# crontab -e

# 写入以下内容

# 每天执行一次
0 0 * * * /usr/local/tomcat/TomcatMonitor.sh

# 或每小时执行一次
0 */1 * * * /usr/local/tomcat/TomcatMonitor.sh
```

![image.png](https://bolo.bienao.life/image/20230518112048087.png)

### 配合 mailx 发送邮件提醒

* mailx 配置部署 - **🌏** [**mailx结合QQ邮箱在Linux下发送系统邮件提醒等**](https://bolo.bienao.life/articles/2023/04/02/1684422957798.html)
* 修改脚本内容如下，其中 `xxxxxxxx@qq.com` 需修改为自己的邮箱

```
#!/bin/bash

# 获取tomcat进程ID
TomcatID=$(ps -ef | grep tomcat | grep '/bin/java' | grep -v grep | awk '{print $2}')

# tomcat启动程序(这里注意tomcat实际安装的路径)
StartTomcat=/usr/local/tomcat/bin/startup.sh
TomcatCache=/usr/local/tomcat/work/*
TomcatTemp=/usr/local/tomcat/temp/*

#定义要监控的页面地址
WebUrl=http://192.68.10.20:8080

#日志输出
GetPageInfo=/usr/local/tomcat/logs/TomcatMonitor.Info
TomcatMonitorLog=/usr/local/tomcat/logs/TomcatMonitor.log

Monitor()
{
    echo "[info]开始监控tomcat...[$(date +'%F %H:%M:%S')]"
    if [ $TomcatID ];then #这里判断Tomcat进程是否存在
        echo "[info]当前tomcat进程ID为:$TomcatID,继续检测页面..."
        # 检测是否启动成功(成功的话页面会返回状态"200")
        TomcatServiceCode=$(curl -s -o $GetPageInfo -m 10 --connect-timeout 10 $WebUrl -w %{http_code})
        if [ $TomcatServiceCode -eq 200 ];then
            echo "[info]页面返回码为$TomcatServiceCode，tomcat启动成功，测试页面正常"
        else
            echo "[error]tomcat页面出错，请注意...状态码为$TomcatServiceCode，错误日志已输出到$GetPageInfo"
            echo "[error]页面访问出错，开始重启tomcat"
            kill -9 $TomcatID # 杀掉原tomcat进程
            sleep 3
            rm -rf $TomcatCache # 清理tomcat缓存
	    rm -rf $TomcatTemp
            $StartTomcat
	    echo -e "[Error]：http://192.68.10.20:8080 页面访问出错，请注意...状态码为$TomcatServiceCode，错误日志已输出至服务器！\\n[Error]：tomcat 进程不存在! tomcat 开始自动重启...\\n[Info]：tomcat 服务已自启成功，服务访问正常，自动化脚本处理完成！"|mailx -v -s "服务访问异常提醒，自动化脚本已处理！" xxxxxxxx@qq.com
        fi
    else    
        echo "[error]tomcat进程不存在!tomcat开始自动重启..."
        echo "[info]$StartTomcat，请稍候..."
	TomcatServiceCode=$(curl -s -o $GetPageInfo -m 10 --connect-timeout 10 $WebUrl -w %{http_code})
        rm -rf $TomcatCache
	rm -rf $TomcatTemp
        $StartTomcat
	echo -e "[Error]：http://192.68.10.20:8080 页面访问出错，请注意...状态码为$TomcatServiceCode，错误日志已输出至服务器！\\n[Error]：tomcat 进程不存在! tomcat 开始自动重启...\\n[Info]：tomcat 服务已自启成功，服务访问正常，自动化脚本处理完成！"|mailx -v -s "服务访问异常提醒，自动化脚本已处理！" xxxxxxxx@qq.com
    fi
    echo "--------------------------"
}
Monitor>>$TomcatMonitorLog
```

