title: CentOS7静态IP地址设置
date: '2023-04-01 21:29:00'
updated: '2023-05-22 13:09:36'
tags: [linux]
permalink: /articles/2023/04/01/1684421570592.html
---
![](https://b3logfile.com/bing/20220821.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 修改配置文件

```
vim /etc/sysconfig/network-scripts/ifcfg-ens33
```

#### 修改

BOOTPROTO=static
ONBOOT=yes

#### 新增

```
IPADDR=设置你的ip
NETMASK=255.255.255.0
GATEWAY=设置你的网关
DNS1=223.6.6.6
DNS2=223.5.5.5
```

### 重启网络

```
# systemctl restart network
```

