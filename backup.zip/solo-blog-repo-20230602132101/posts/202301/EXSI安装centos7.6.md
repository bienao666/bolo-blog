title: EXSI安装centos7.6
date: '2023-01-17 04:09:19'
updated: '2023-05-22 00:57:17'
tags: [EXSI, centos]
permalink: /articles/2023/01/17/1673946559428.html
---
![](https://b3logfile.com/bing/20190324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 准备

　　[镜像点我下载](http://121.43.32.165:10025/d/2.%E7%B3%BB%E7%BB%9F%E9%95%9C%E5%83%8F/Centos7/CentOS-7-x86_64-DVD-2009.iso)

# 上传镜像

### 点击存储，点击数据存储浏览器

![image.png](https://bolo.bienao.life/image/20230117190546827.png)

### 新建目录

![image.png](https://bolo.bienao.life/image/20230117190711524.png)

### 上传

选择新建的目录，点击上传，选中刚刚下载的文件

![image.png](https://bolo.bienao.life/image/20230117190826802.png)

# 创建虚拟机

### 创建/注册虚拟机

![image.png](https://bolo.bienao.life/image/20230117191909303.png)

### 创建新虚拟机

![image.png](https://bolo.bienao.life/image/20230117191930864.png)

### 选择名称和客户机操作系统

名称随便填
客户机操作系统系列：Linux
客户机操作系统版本：CentOS7（64位）

![image.png](https://bolo.bienao.life/image/20230117192059174.png)

### 选择存储

我这就一个固态硬盘，就默认这个

![image.png](https://bolo.bienao.life/image/20230117192215175.png)

### 自定义设置

CPU：自己看着配置
内存：自己看着配置
硬盘1：自己看着配置
CD/DVD 驱动器 1：选择数据存储ISO文件，选刚刚上传的centos7.6镜像

![image.png](https://bolo.bienao.life/image/20230117192548900.png)

### 完成

![image.png](https://bolo.bienao.life/image/20230117192610327.png)

# 安装

### 点击虚拟机列表

![image.png](https://bolo.bienao.life/image/20230117192723510.png)

### 点击刚刚创建的虚拟机

![image.png](https://bolo.bienao.life/image/20230117192746120.png)

### 打开电源

![image.png](https://bolo.bienao.life/image/20230117192809969.png)

### 点击虚拟机显示器

![image.png](https://bolo.bienao.life/image/20230117192835805.png)

### 点击显示器，按回车

![image.png](https://bolo.bienao.life/image/20230117192935686.png)

### 选择中文

![image.png](https://bolo.bienao.life/image/20230117193502981.png)

### 软件选择

![image.png](https://bolo.bienao.life/image/20230117194210629.png)

### 选择基础设施服务器

![image.png](https://bolo.bienao.life/image/20230117194318606.png)

### 网络和主机名

![image.png](https://bolo.bienao.life/image/20230117194417548.png)

### 配置

![image.png](https://bolo.bienao.life/image/20230117194441650.png)

### IPv4配置

![image.png](https://bolo.bienao.life/image/20230117194600709.png)

方法：手动
点击ADD
地址：找个你局域网没有被占用的ip
子网掩码：255.255.255.0
网关：看你自己局域网的网关

![image.png](https://bolo.bienao.life/image/20230117194742008.png)

### 开启以太网

![image.png](https://bolo.bienao.life/image/20230117194822216.png)

### 开始安装

![image.png](https://bolo.bienao.life/image/20230117194846584.png)

### 设置密码

![image.png](https://bolo.bienao.life/image/20230117194905238.png)

![image.png](https://bolo.bienao.life/image/20230117194927521.png)

### 安装中

![image.png](https://bolo.bienao.life/image/20230117194956823.png)

### 重启

![image.png](https://bolo.bienao.life/image/20230117200236244.png)

### 登陆

账号：root
密码：刚刚上面设置的

![image.png](https://bolo.bienao.life/image/20230117200409565.png)

### 安装成功

![image.png](https://bolo.bienao.life/image/20230117200434719.png)

