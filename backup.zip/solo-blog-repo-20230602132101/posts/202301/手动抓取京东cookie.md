title: 手动抓取京东cookie
date: '2023-01-05 22:15:00'
updated: '2023-05-22 01:18:53'
tags: [京东, 京东cookie, 青龙面板]
permalink: /articles/2023/01/06/1672974976088.html
---
![image.png](http://121.43.32.165:10012/image/20230106111750622.png)

# 介绍

&nbsp;&nbsp;&nbsp;&nbsp;Cookie是为了辨别用户身份，进行Session跟踪而储存在用户本地终端上的数据（通常经过加密），由用户客户端计算机暂时或永久保存的信息;
&nbsp;&nbsp;&nbsp;&nbsp;对于我们薅京东而言，只要知道需要京东cookie才能跑脚本就行了。
&nbsp;&nbsp;&nbsp;&nbsp;由于京东近期加强了验证，个别好短信登陆服务登不上，所以需要手动抓取下。

# 1.手机端

安卓端免费使用，IOS需要收费安装(用电脑端抓取吧)

应用商店下载Alook浏览器，或者官方网站下载https://alookweb.com/

### 1.1 打开京东网页端

浏览器输入https://m.jd.com
ps：请勿跳转APP端，网页端登录
![image.png](https://bolo.bienao.life/image/20230106215129026.png)

### 1.2 登陆

![image.png](https://bolo.bienao.life/image/20230106215210080.png)

### 1.3 点击浏览器菜单栏

![image.png](https://bolo.bienao.life/image/20230106215318522.png)

### 1.4 选择工具箱

![image.png](https://bolo.bienao.life/image/20230106215355954.png)

### 1.5选择开发者工具

![image.png](https://bolo.bienao.life/image/20230106215438841.png)

### 1.6 选择Cookie

![image.png](https://bolo.bienao.life/image/20230106215510063.png)

### 1.7 提取cookie

从复制出来的内容里提取`pt_key=xxxx; pt_pin=yyyy;`

![image.png](https://bolo.bienao.life/image/20230106215619790.png)

# 2.电脑端

### 2.1 打开京东网页端

* **[点我登陆](https://m.jd.com)**
* 或者浏览器输入https://m.jd.com

![image.png](https://bolo.bienao.life/image/20230106104121378.png)

### 2.2 登陆

点击右下角未登录，输入手机号，验证码，点击登陆
ps：有个手势安全验证比较恶心，可能一次性验证过，也可能画很多次都过不了，多刷新多试吧，没法
ps：有的号会提示认证，这是因为京东最近加强了验证方式，所以个别号短信登陆不了，点击身份证号认证，输入身份证前两位和后四位（**这是京东的官方网站，可以放心验证**）

![image.png](https://bolo.bienao.life/image/20230106104308850.png)

### 2.3 进入京东页面

1. 点击右上角的直接访问
2. 点击中间的×关掉弹窗

![image.png](https://bolo.bienao.life/image/20230106105310688.png)

### 2.4 打开浏览器开发者工具

我这是用的谷歌浏览器做的教程，其他浏览器也都类似，都可以抓
ps：[谷歌浏览器需要的可以点我下载安装](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E7%94%B5%E8%84%91/%E7%A8%8B%E5%BA%8F%E5%91%98%E5%BC%80%E5%8F%91/JAVA/chrome/89.0.4389.128_chrome_installer_64.exe)

按F12会在右边或者下边出现开发者工具
![image.png](https://bolo.bienao.life/image/20230106105639223.png)

### 2.5 触发请求

点击左下角的首页,如果红框里面条数太多的话可以点下上面Doc

![image.png](https://bolo.bienao.life/image/20230106110214710.png)

### 2.6 提取cookie

随便点击一条数据，点击右上角Headers，往下滑找到cookie数据，提取`pt_key=xxxx; pt_pin=yyyy;`

![image.png](https://bolo.bienao.life/image/20230106110750715.png)

---

**有不懂的欢迎在下方评论**

