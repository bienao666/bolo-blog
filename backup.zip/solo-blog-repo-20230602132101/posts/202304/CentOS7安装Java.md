title: CentOS 7 安装 Java
date: '2023-04-05 06:11:00'
updated: '2023-05-22 01:11:27'
tags: [linux, java]
permalink: /articles/2023/04/05/1684423764812.html
---
![](https://b3logfile.com/bing/20190327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 下载

#### 手动下载后手动上传

[点我下载](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E6%9C%8D%E5%8A%A1%E5%99%A8/linux/jdk/jdk%208/jdk-8u333-linux-x64.tar.gz)

#### 命令行下载

```
wget http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E6%9C%8D%E5%8A%A1%E5%99%A8/linux/jdk/jdk%208/jdk-8u333-linux-x64.tar.gz
```

### 安装

```
tar -zxvf jdk-8u333-linux-x64.tar.gz -C /usr/local/
mv /usr/local/jdk1.8.0_333 /usr/local/jdk
```

### 配置环境变量

```
vim /etc/profile
```

```
# 写入以下内容

export JAVA_HOME=/usr/local/jdk
export PATH=$PATH:$JAVA_HOME/bin:$JAVA_HOME/jre/bin
```

![image.png](https://bolo.bienao.life/image/20230518112912813.png)

* 键入以下命令使配置修改生效

```
source /etc/profile
```

### 测试安装结果

```
java -version
```

