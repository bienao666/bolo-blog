title: Centos7服务器挂代理方法
date: '2023-04-06 02:29:00'
updated: '2023-05-22 01:11:46'
tags: [代理]
permalink: /articles/2023/04/06/1684425717623.html
---
![](https://b3logfile.com/bing/20221105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 永久生效

**修改 /etc/profile 文件，添加下面内容:**

```
vim /etc/profile  #编辑profile文件
```

**添加Proxy代理信息（其中username和password根据需要填写，若无去掉 username:password@）**

```
http_proxy = http://username:password@proxy_ip:port/

https_proxy = http://username:password@proxy_ip:port/

ftp_proxy = http://username:password@proxy_ip:port/

export http_proxy

export https_proxy

export ftp_proxy
```

**生效配置**

```
source /etc/profile
```

# 二、临时生效（重连失效）

**其中username和password根据需要填写，若无去掉 username:password@**

```
export http_proxy=http://username:password@yourproxy:port/
export https_proxy=http://username:password@yourproxy:port/
export ftp_proxy=http://username:password@yourproxy:port/
```

