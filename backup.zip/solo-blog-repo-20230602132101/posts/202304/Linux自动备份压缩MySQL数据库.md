title: Linux 自动备份压缩 MySQL 数据库
date: '2023-04-04 06:11:00'
updated: '2023-05-22 01:11:08'
tags: [linux, mysql]
permalink: /articles/2023/04/04/1684423515411.html
---
![](https://b3logfile.com/bing/20190414.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 创建脚本

```
# vim /home/backup/mysqlbackup.sh
```

```
# 写入以下内容

#!/bin/bash

# 数据库IP地址
db_host="192.168.10.15"

# 数据库端口
db_port="3306"

# 数据库登陆用户名
db_user="root"

# 数据库登录密码
db_passwd="123456"

# 需备份的库
db_name="solo"

# 备份文件存放路径
backup_path="/home/backup/mysql"

# 定义备份文件的文件名格式
name="solo-$(date +"%Y-%m-%d-%H:%M:%S")"

# 执行备份命令，并压缩备份文件
mysqldump --flush-logs --user=$db_user --password=$db_passwd --host=$db_host --port=$db_port $db_name | gzip > $backup_path/$name.sql.gz

# 将备份文件传至192.168.10.20，即192.168.10.15和192.168.10.20两台服务器都会保存备份文件 - 可选是否添加此命令
scp -r $backup_path/$name.sql.gz root@192.168.10.20:$backup_path

# 删除7天前的备份
find $backup_path/* -mtime +7 -name "*.gz" -exec rm -rf {} \;
```

![image.png](https://bolo.bienao.life/image/20230518112454831.png)

### 脚本授权

```
# chmod +x /home/backup/mysqlbackup.sh
```

### 定时任务

```
# crontab -e

# 写入以下内容

# 每小时备份一次
0 */1 * * * /home/backup/mysqlbackup.sh
```

![image.png](https://bolo.bienao.life/image/20230518112427777.png)

* 重启 crond 服务

```
# systemctl restart crond
```

