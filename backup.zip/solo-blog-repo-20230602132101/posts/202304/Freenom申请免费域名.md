title: Freenom申请免费域名
date: '2023-04-08 06:29:00'
updated: '2023-05-22 01:14:04'
tags: [域名]
permalink: /articles/2023/04/08/1684426010107.html
---
![](https://b3logfile.com/bing/20190221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 准备材料

一枚邮箱

美国代理（最好一直开着，直接大陆本地直连或者除美国其他地区连接虽然可以，从我自己测试效果讲美国ip更容易过一点，但可以多多尝试）

**PS：后面的一些问题，比如邮箱收不到验证码啥的问题，都是代理问题，请切换大陆外代理，推荐美国IP代理；如果域名没法注册，或者最后一步出故障了，请注意IP地址和账号地址是否一致或者切换到国外代理**

# 过程

1.点击[这里](https://ipinfo.io/)，查看你自己的IP所在国家
![image.png](https://bolo.bienao.life/image/20230518120427475.png)

2.打开[Freenom官网](https://www.freenom.com/en/index.html)

3.依次点击“Partners”→“Developers”
![image.png](https://bolo.bienao.life/image/20230518120450563.png)

4.把网页往下拉，点击绿色的“Get a Random Domains Account today!”

5.输入邮箱地址，然后点击“Verify my Email address”

6.检查收件箱内的Freenom激活邮件

7.在弹出的网页中，输入你自己想要注册的域名

PS:搜索你需要的域名， **最好（甚至一定）带后缀** ，否则都是不可用

freenom最常见的域名后缀一般是：tk ml ga cf gq 等等

8.点击绿色的“Checkout”按钮
![image.png](https://bolo.bienao.life/image/20230518120510558.png)

9.选择使用期限，选择12Months，点击“Continue”

10.把上面的域名服务取消掉
![image.png](https://bolo.bienao.life/image/20230518120529625.png)

11.填入IP所在国家的个人信息，同意协议，点击“Complete Order”

12.注册成功
![image.png](https://bolo.bienao.life/image/20230518120549647.png)

如果注册提示错误，请依次点击“Hello, xxx”→“Edit account details”进行个人信息修改，注意填写国家一定是要和IP地址一致
![image.png](https://bolo.bienao.life/image/20230518120605722.png)

13.依次点击“Services”→“My Domains”

14.在这里可以看到你注册的域名，点击“Manage Domain”

**PS:如果域名没有，就是ip不行，或者地址不对。不要再问了，经过几百个问题者的排查，只有这两个问题；如果地址对了，就是ip不够纯净！ip不够纯净！ip不够纯净！**

15.进行相应的修改

比如DNS转移到CF
![image.png](https://bolo.bienao.life/image/20230518120624326.png)

