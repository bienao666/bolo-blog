title: CentOS 7 安装 Tomcat 9
date: '2023-04-07 11:29:00'
updated: '2023-05-22 01:12:04'
tags: [linux, Tomcat]
permalink: /articles/2023/04/07/1684424069889.html
---
![](https://b3logfile.com/bing/20220813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 将 `Tomcat` 安装包下载到服务器中

```
wget http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E6%9C%8D%E5%8A%A1%E5%99%A8/linux/tomcat/apache-tomcat-9.0.67.tar.gz
```

### 解压 `Tomcat` 至 `/usr/local` 目录中

```
tar -zxvf apache-tomcat-9.0.67.tar.gz -C /usr/local/
cd /usr/local
mv apache-tomcat-9.0.67 tomcat
```

### 启停 `Tomcat`

* 启动服务

```
cd /usr/local/tomcat/bin./startup.sh ;tailf ../logs/catalina.out
```

* 关闭服务

```
cd /usr/local/tomcat/bin./shutdown.sh

# 或
ps -ef |grep tomcat
kill -9 pid
```

### 开机自启动设置

* **编辑 `/etc/rc.d/rc.local` 文件**

```
vim /etc/rc.d/rc.local
```

```
# 写入以下内容 -- tomcat服务路径，jdk环境变量，按实际修改，多tomcat服务，则写入多条tomcat服务启动命令

export JAVA_HOME=/usr/local/jdk
export PATH=$PATH:$JAVA_HOME/bin
/usr/local/tomcat/bin/startup.sh start
```

![image.png](https://bolo.bienao.life/image/20230518113402457.png)

* **给予 **`/etc/rc.d/rc.local`** 文件可执行权限**

```
chmod +x /etc/rc.d/rc.local
```

![image.png](https://bolo.bienao.life/image/20230518113416253.png)

