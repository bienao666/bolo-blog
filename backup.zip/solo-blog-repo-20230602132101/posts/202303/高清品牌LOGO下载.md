title: 高清品牌LOGO下载
date: '2023-03-29 00:29:00'
updated: '2023-05-22 01:04:37'
tags: [LOGO下载]
permalink: /articles/2023/03/29/1684420588861.html
---
![](https://b3logfile.com/bing/20201129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### [WORLDVECTORLOGO](https://worldvectorlogo.com/)

  可以免费下载来自世界各地大小公司的 LOGO，方便用于案例参考、方案写作、平面设计、PPT 设计，视频创作当中；直接搜索即可获取特定品牌 LOGO ，下载下来的 SVG 等格式足够高清好用（比如微信），再也不用自己到处找 LOGO ，或者自己模拟做了；
![image.png](https://bolo.bienao.life/image/20230518103526537.png)

