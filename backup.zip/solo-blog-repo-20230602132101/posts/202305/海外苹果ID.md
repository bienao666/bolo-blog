title: 海外苹果ID
date: '2023-05-23 10:11:00'
updated: '2023-05-23 10:14:42'
tags: [技术]
permalink: /articles/2023/05/23/1684851200994.html
---
![](https://b3logfile.com/bing/20180902.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 为什么需要非中国大陆区 Apple ID

部分应用无法上架中国大陆区 App Store，所以用户需要使用非中国大陆区 Apple ID 从 App Store 下载安装。

# 准备

1. 手机号
2. 邮箱

# PS

如果只是需要下载小火箭的话，需要3$≈21元，[点我购买只要3元喔](https://shop.bienao.life/buy/29)

# 申请

## 注册：

在电脑端打开 [苹果官网](https://appleid.apple.com/account)，按照要求填写姓名、国家或地区（此处需选择美国）、邮箱、密码以及手机号码即可。

![image.png](https://bolo.bienao.life/image/20230523092420650.png)

完成之后，Apple 会根据你填的邮箱和手机，发送验证码。之后你只需要在对应的框里输入对应的验证码。

![image.png](https://bolo.bienao.life/image/20230523092602742.png)

![image.png](https://bolo.bienao.life/image/20230523092635943.png)

## 编辑地址

此时，你就已经进入你的 ID 页面了，点击「付款和送货」的「编辑」。

![image.png](https://bolo.bienao.life/image/20230523093048943.png)

## 获取美国地址

按照要求，填写有效的美国地址和电话号码。（[美国身份生成点我](https://www.shenfendaquan.com/)）

PS:一定要选择以下五大免税州，不然要额外扣税

1. 阿拉斯加州（Alaska）首府：朱诺（Juneau）邮编：99850  电话区号：907
2. 特拉华州（Delaware）邮编：19702 电话区号：302
3. 蒙大拿州（Montana）城市：Marion邮编：26586   电话区号：406
4. 新罕布什尔州（New Hampshire）城市：Fremont邮编：03044  电话区号：603
5. 俄勒冈州（Oregon）城市：ANTELOPE  邮编：97001  电话区号：503  、  971

![image.png](https://bolo.bienao.life/image/20230523093632771.png)

![image.png](https://bolo.bienao.life/image/20230523094032918.png)

## 登录苹果id

因为是新 Apple ID 第一次登录，所以会有「检查」的提示。接着，请点击「同意条款与权限」。

![image.png](https://bolo.bienao.life/image/20230523095531102.png)

![image.png](https://bolo.bienao.life/image/20230523095545908.png)

这边又填了一遍地址

![image.png](https://bolo.bienao.life/image/20230523095611808.png)

可以成功开始使用了！

![image.png](https://bolo.bienao.life/image/20230523095631853.png)

## 苹果账号充值

### 地址切换旧金山

![image.png](https://bolo.bienao.life/image/20230523100709083.png)

### 点击大牌折扣礼卡

![image.png](https://bolo.bienao.life/image/20230523100736807.png)

### 充值你需要的金额

![image.png](https://bolo.bienao.life/image/20230523100803214.png)

### 兑换

打开 App Store，点击个人头像，点击兑换， 输入兑换码后，即可兑换成功。

![image.png](https://bolo.bienao.life/image/20230523101004519.png)

