title: Jar包转exe
date: '2023-05-27 00:32:00'
updated: '2023-05-27 02:11:32'
tags: [Java]
permalink: /articles/2023/05/27/1685166433846.html
---
![](https://b3logfile.com/bing/20191210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 介绍

exe4j 可以很容易吧一个 jar 打包成 exe。但是对于一些刚接触 java 或者刚接触 exe4j 的朋友来说，看看这个教程还是很有帮助的。

# 准备

1. 安装JDK环境
2. 下载安装exe4j([点我下载](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E7%94%B5%E8%84%91/%E7%BC%96%E7%A8%8B%E8%BD%AF%E4%BB%B6/JAVA/exe4j/exe4j_windows-x64_9_0.exe))

# 破解

* 姓名：随便填
* 公司：随便填
* 许可证秘钥：`L-g782dn2d-1f1yqxx1rv1sqd

![image.png](https://bolo.bienao.life/image/20230527005853711.png)

# 打包

## 1.直接点下一步

![image.png](https://bolo.bienao.life/image/20230527010155466.png)

## 2.JAR包打EXE

![image.png](https://bolo.bienao.life/image/20230527010240845.png)

## 3.指定程序名称及输出目录

![image.png](https://bolo.bienao.life/image/20230527010448141.png)

## 4.指定程序名称和图标

图标必须为ico格式的图片，可以去[爱给网](https://www.aigei.com)找一些免费的，或者去网上找一些在线转ico图片

![image.png](https://bolo.bienao.life/image/20230527011626506.png)

## 5.选择需要打包的jar包

![image.png](https://bolo.bienao.life/image/20230527011836584.png)

## 6.选择启动项

![image.png](https://bolo.bienao.life/image/20230527015406323.png)

## 7.根据你安装的JDK版本输入

![image.png](https://bolo.bienao.life/image/20230527014405849.png)

## 8.配置JRE

![image.png](https://bolo.bienao.life/image/20230527020057138.png)

## 9.选第二个

![image.png](https://bolo.bienao.life/image/20230527012801622.png)

## 10.下一步

![image.png](https://bolo.bienao.life/image/20230527012846180.png)

![image.png](https://bolo.bienao.life/image/20230527012858451.png)

## 11.打包完成并保存当前打包配置

![image.png](https://bolo.bienao.life/image/20230527013023213.png)

## 12.查看输出目录

1. xxx.exe就是打包好的执行程序
2. xxx.exe4j就是一键打包程序，下次打包只要jar包和程序图标位置不变，可以双击此程序，直接点击完成就行了，无需重复上序步骤

![image.png](https://bolo.bienao.life/image/20230527013219965.png)

## 13.测试程序

### 双击exe

![image.png](https://bolo.bienao.life/image/20230527013907402.png)

### 正常启动

![image.png](https://bolo.bienao.life/image/20230527021058161.png)

### 正常访问

![image.png](https://bolo.bienao.life/image/20230527021005661.png)

