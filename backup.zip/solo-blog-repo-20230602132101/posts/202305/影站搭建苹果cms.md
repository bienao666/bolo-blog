title: 影站搭建-苹果cms
date: '2023-05-21 22:09:00'
updated: '2023-06-02 09:00:29'
tags: [影站]
permalink: /articles/2023/05/21/1684733281006.html
---
![image.png](https://bolo.bienao.life/image/20230526053151390.png)

# 苹果cms 简介

苹果cms是个人最常用的搭建视频影视站的CMS管理系统，有些人也会选择YYcms以及海洋CMS。今天我们来说一下苹果CMS管理系统的详细搭建教程。对于新手来讲可能还不太清楚如何来建站入门安装配置教程。

# 演示

[别闹影视](https://www.bienao.life)

# 准备

由于国内备案比较麻烦，我这边用国外服务器以及国外域名做演示，你也可以用国内的，操作都差不多，但是国内可能会有侵权问题

## 服务器(vps)

推荐使用2核2G 40G以上硬盘即可，当然1核也能安装，不过采集资源时，可能会超负载。

1. racknerd是我买的比较多美国服务器，价格很亲民，[点我购买](https://my.racknerd.com/aff.php?aff=7148)，系统选择centos7.9

![image.png](https://bolo.bienao.life/image/20230519095850201.png)

2. 热网互联是我用的香港服务器，相对于racknerd价格要贵上一些，但是靠近大陆，线路优化也好[点我购买](https://www.hotiis.com/?ref=9z2BsW0q)
   
   ![image.png](https://bolo.bienao.life/image/20230522015848886.png)

## 域名

namesilo是我自己用的域名，[点我购买](https://www.namesilo.com/?rid=d7a2698ub)，你也可以白嫖Freenom的域名，[白嫖教程点我](https://bolo.bienao.life/articles/2023/04/08/1684426010107.html)

## 域名解析

此次示例域名：www.bienaoccc.life

[点我查看教程](https://bolo.bienao.life/articles/2023/05/19/1684509051675.html)

# 搭建

## 安装aaPanel(宝塔)

### 命令安装

#### 国外安装

```
yum install -y wget && wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh && bash install.sh
```

#### 国内安装

```
yum install -y wget && wget -O install.sh https://download.bt.cn/install/install_6.0.sh && sh install.sh ed8484bec
```

记得保存一下宝塔面板地址，账号，密码

![image.png](https://bolo.bienao.life/image/20230519131939465.png)

### 打开宝塔面板

![image.png](https://bolo.bienao.life/image/20230519132427963.png)

![image.png](https://bolo.bienao.life/image/20230519132503147.png)

![image.png](https://bolo.bienao.life/image/20230519132520501.png)

### 安装基础环境

![image.png](https://bolo.bienao.life/image/20230519132618700.png)

![image.png](https://bolo.bienao.life/image/20230519132659852.png)

## 安装相关服务

![image.png](https://bolo.bienao.life/image/20230522023627936.png)

## 搭建站点

![image.png](https://bolo.bienao.life/image/20230522023834798.png)

## 设置ssl

![image.png](https://bolo.bienao.life/image/20230522090036681.png)

## 下载源码

### 删除原文件

![image.png](https://bolo.bienao.life/image/20230522083412472.png)

![image.png](https://bolo.bienao.life/image/20230522083449491.png)

### 下载cms10源码

```
https://github.com/magicblack/maccms10/archive/refs/tags/v2023.1000.3050.tar.gz
```

![image.png](https://bolo.bienao.life/image/20230522083832419.png)

### 解压文件

![image.png](https://bolo.bienao.life/image/20230522084108878.png)

![image.png](https://bolo.bienao.life/image/20230522084430582.png)

![image.png](https://bolo.bienao.life/image/20230522084909632.png)

![image.png](https://bolo.bienao.life/image/20230522084517813.png)

![image.png](https://bolo.bienao.life/image/20230522084817239.png)

## 修改文件名称

名称随便改个，这个是后台访问路径

![image.png](https://bolo.bienao.life/image/20230522084653639.png)

![image.png](https://bolo.bienao.life/image/20230522085009638.png)

## 安装影站

![image.png](https://bolo.bienao.life/image/20230522085326558.png)

![image.png](https://bolo.bienao.life/image/20230522085220885.png)

![image.png](https://bolo.bienao.life/image/20230522085243980.png)

![image.png](https://bolo.bienao.life/image/20230522085701461.png)

## 访问后台

```
https://域名/上面修改后的文件名称
```

![image.png](https://bolo.bienao.life/image/20230522085837985.png)

## 设置视频分类

![image.png](https://bolo.bienao.life/image/20230522094638117.png)

## 设置影视采集

以[量子资源站](http://cj.lziapi.com/help/#MacCms10)为例，更多视频资源接口请往下看

### 复制资源接口

![image.png](https://bolo.bienao.life/image/20230522090947593.png)

### 添加资源

![image.png](https://bolo.bienao.life/image/20230522091408443.png)

### 绑定分类

![image.png](https://bolo.bienao.life/image/20230522094731151.png)

![image.png](https://bolo.bienao.life/image/20230522095416675.png)

### 采集所有

![image.png](https://bolo.bienao.life/image/20230522095654978.png)

### 定时采集

#### 复制采集当天链接地址

![image.png](https://bolo.bienao.life/image/20230522095933889.png)

#### 设置定时任务

![image.png](https://bolo.bienao.life/image/20230522100226948.png)

![image.png](https://bolo.bienao.life/image/20230522100452371.png)

![image.png](https://bolo.bienao.life/image/20230522100539385.png)

![image.png](https://bolo.bienao.life/image/20230522101137968.png)

#### 测试定时任务

![image.png](https://bolo.bienao.life/image/20230522101734830.png)

## 配置播放器

![image.png](https://bolo.bienao.life/image/20230522103906678.png)

## 导入模板

模板在博客最后下载，下载后上传模板

![image.png](https://bolo.bienao.life/image/20230522103059030.png)

![image.png](https://bolo.bienao.life/image/20230522103155562.png)

![image.png](https://bolo.bienao.life/image/20230522103247464.png)

## 设置模板

![image.png](https://bolo.bienao.life/image/20230522103351553.png)

## 资源分享

如果有好的影视资源和模板资源，欢迎分享给我

### 影视接口

不要设置太多，选2-3个质量好点的接口

1. [U酷资源](https://www.ukuzy.com/help/#MacCms10)
2. [量子资源](http://cj.lziapi.com/help/#MacCms10)
3. [百度云资源](https://www.bdzy.com)
4. [红牛资源](https://www.hongniuzy.com/help/#MacCms10)
5. [无尽资源](http://help.wujinapi.me/#MacCms10)
6. [淘片资源](https://www.taopianzy.com/help/mc10.html)
7. [飞速资源](https://help.feisuzyapi.com/#MacCms10)
8. [云解析资源](https://www.yparse.com/help/maccms.html)

### 模板资源

#### 免费资源

1. 模板1
   
   [点我下载](http://121.43.32.165:10025/d/4.%E8%B5%84%E6%BA%90%E5%A4%A7%E5%85%A8/%E8%8B%B9%E6%9E%9CCMS10/%E5%85%8D%E8%B4%B9/template1.zip)
   
   ![image.png](https://bolo.bienao.life/image/20230522123146240.png)

#### 付费资源

1. 模板v1
   
   [点我购买](https://shop.bienao.life/buy/30)
   
   ![image.png](https://bolo.bienao.life/image/20230522123238270.png)

