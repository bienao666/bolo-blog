title: 减少 ChatGPT 官方网页需要频繁刷新的简单办法
date: '2023-05-09 11:50:00'
updated: '2023-05-22 01:13:54'
tags: [ChatGPT]
permalink: /articles/2023/05/09/1683595229457.html
---
### 多开一个标签页，访问一个需要过验证但又不会有交互请求的链接，例如：

https://chat.openai.com/404

### 装个自动刷新的脚本

https://greasyfork.org/zh-CN/scripts/462967

