title: 尝试将更多数据写入响应标头，而不是缓冲区中有可用空间。+增加连接器上的maxHttpHeaderSize或将更少的数据写入响应头
date: '2023-05-24 01:15:00'
updated: '2023-05-24 05:23:45'
tags: [tomcat]
permalink: /articles/2023/05/24/1684920115083.html
---
![](https://b3logfile.com/bing/20181221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 报错信息

tomcat部署bolo，打开博客时遇到以下错误：

org.apache.coyote.http11.HeadersTooLargeException
尝试将更多数据写入响应标头，而不是缓冲区中有可用空间。+增加连接器上的maxHttpHeaderSize或将更少的数据写入响应头

# 报错原因

tomcat配置中的server.xml里没有指定 maxHttpHeaderSize 的大小。

# 解决方法

在tomcat下的conf文件夹下的server.xml文件里添加指定 maxHttpHeaderSize 大小，重启tomcat

```
<Connector port="8080" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" 
               maxHttpHeaderSize ="102400" />
```

