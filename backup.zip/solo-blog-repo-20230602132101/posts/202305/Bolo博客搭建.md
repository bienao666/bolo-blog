title: Bolo 博客搭建
date: '2023-05-19 22:09:00'
updated: '2023-05-22 22:09:25'
tags: [博客]
permalink: /articles/2023/05/19/1684505816984.html
---
![image.png](https://bolo.bienao.life/image/20230519095316504.png)

# Bolo 简介

Bolo 是基于 Java 的一款开源博客引擎，它基于 Latke 框架搭建，响应速度快，占用资源小，Bolo 完全免费，代码全部开源且允许二次开发自用。如果你在寻找一款美观、全面但不复杂的个人博客引擎 —— 欢迎加入到 Bolo 用户的大家庭中来。

# 准备

由于国内备案比较麻烦，我这边用国外服务器以及国外域名做演示，你也可以用国内的，操作都差不多

## 服务器(vps)

racknerd是我买的比较多国外服务器，价格很亲民，[点我购买](https://my.racknerd.com/aff.php?aff=7148)，系统选择centos7.9

![image.png](https://bolo.bienao.life/image/20230519095850201.png)

## 域名

namesilo是我自己用的域名，[点我购买](https://www.namesilo.com/?rid=d7a2698ub)，你也可以白嫖Freenom的域名，[白嫖教程点我](https://bolo.bienao.life/articles/2023/04/08/1684426010107.html)

## 域名解析

[点我查看教程](https://bolo.bienao.life/articles/2023/05/19/1684509051675.html)

# 搭建

## 安装aaPanel(宝塔)

### 命令安装

#### 国外安装

```
yum install -y wget && wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh && bash install.sh
```

#### 国内安装

```
yum install -y wget && wget -O install.sh https://download.bt.cn/install/install_6.0.sh && sh install.sh ed8484bec
```

记得保存一下宝塔面板地址，账号，密码

![image.png](https://bolo.bienao.life/image/20230519131939465.png)

### 打开宝塔面板

![image.png](https://bolo.bienao.life/image/20230519132427963.png)

![image.png](https://bolo.bienao.life/image/20230519132503147.png)

![image.png](https://bolo.bienao.life/image/20230519132520501.png)

### 安装基础环境

![image.png](https://bolo.bienao.life/image/20230519132618700.png)

![image.png](https://bolo.bienao.life/image/20230519132659852.png)

### 安装tomcat

#### 国外安装

国外服务器命令行下载比较慢，可以选择手动下载后自己上传，嫌麻烦就命令行直接下载

[安装jdk教程](https://bolo.bienao.life/articles/2023/04/05/1684423764812.html)

![image.png](https://bolo.bienao.life/image/20230519134829523.png)

[安装tomcat教程](https://bolo.bienao.life/articles/2023/04/07/1684424069889.html)，解压完那步就行，暂时不用启动

#### 国内安装

![image.png](https://bolo.bienao.life/image/20230519133533849.png)

![image.png](https://bolo.bienao.life/image/20230519133747335.png)

## 上传源码

### 国外上传

1. 删除多余文件
   
   ```
   cd /usr/local/tomcat/webapps
   rm -rf docs examples host-manager manager
   cd ROOT
   rm -rf ./*
   ```
2. 下载源码
   
   ```
   wget https://github.com/adlered/bolo-solo/releases/download/v2.6_stable/bolo_v2_6_stable.zip
   unzip bolo_v2_6_stable.zip
   ```

### 国内上传

1. 删除多余文件
   
   ```
   cd /`www/server`/tomcat/webapps
   rm -rf docs examples host-manager manager
   cd ROOT
   rm -rf ./*
   ```
2. 下载源码
   
   ```
   wget https://ftp.stackoverflow.wiki/bolo/releases/bolo_v2_6_stable.zip
   unzip bolo_v2_6_stable.zip
   ```

## 新建数据库

数据库名称，用户名，密码自己设置，允许选择每个人

![image.png](https://bolo.bienao.life/image/20230519140954922.png)

## 配置数据库

### 国外配置文件路径

![image.png](https://bolo.bienao.life/image/20230519141352698.png)

### 国内配置文件路径

![image.png](https://bolo.bienao.life/image/20230519141545386.png)

### 配置以下三个数据

就是上面新建数据库时的用户名，密码，数据库名称，注意保存

![image.png](https://bolo.bienao.life/image/20230519141749507.png)

## 创建站点

域名就是上面申请的域名，描述和路径自己填

![image.png](https://bolo.bienao.life/image/20230519145811019.png)

## 配置ssl

![image.png](https://bolo.bienao.life/image/20230519145838799.png)

## 配置反向代理

![image.png](https://bolo.bienao.life/image/20230519143750161.png)

## 修改博客配置文件

### 国外配置文件路径

![image.png](https://bolo.bienao.life/image/20230519143925863.png)

### 国内配置文件路径

![image.png](https://bolo.bienao.life/image/20230519144016767.png)

### 配置https

注意保存

![image.png](https://bolo.bienao.life/image/20230519144048685.png)

## 启动tomcat

### 国外启动

```
cd /usr/local/tomcat/bin && ./startup.sh
```

### 国内启动

![image.png](https://bolo.bienao.life/image/20230519145538778.png)

## 部署

### 访问博客

浏览器输入你的域名

![image.png](https://bolo.bienao.life/image/20230519144509224.png)

### 初始化

设置账号和密码

![image.png](https://bolo.bienao.life/image/20230519144712929.png)

### BOLO部署完成

赶紧写起你的博客吧😋

![image.png](https://bolo.bienao.life/image/20230519144841064.png)

![image.png](https://bolo.bienao.life/image/20230519145342451.png)

也希望大家把我的博客加入你的友链，本站信息如下：

```
名称：别闹的个人博客
简介：一个什么都会发的小博客！
网址：https://bolo.bienao.life
头像：https://bolo.bienao.life/image/bolo.png
```

## 申领友链要求

1. 请先添加本站为友链后再申请友链，在下方评论留下网站信息
2. 不和剽窃、侵权、无诚信的网站交换，优先和具有原创作品的全站 HTTPS 站点交换
3. 原则上要求您的博客主页被百度或者 Google 等搜索引擎收录
4. 由于访问安全性问题，请务必提供 HTTPS 链接的头像地址（或留言时备注暂无以便本站主动保存）

