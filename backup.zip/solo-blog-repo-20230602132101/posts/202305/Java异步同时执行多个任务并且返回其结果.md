title: Java 异步同时执行多个任务，并且返回其结果
date: '2023-05-25 00:32:00'
updated: '2023-05-27 02:18:11'
tags: [Java]
permalink: /articles/2023/05/25/1684996226768.html
---
![](https://b3logfile.com/bing/20230509.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 需求

我爬取了不少JetBrains全家桶激活接口，这个时效性很短，需要筛选一下有效并还有激活名额的激活服务器地址，数量一多，接口执行就慢，于是加上了多线程异步执行，最终返回。

# 采用Hutool工具

```
<dependency>
     <groupId>cn.hutool</groupId>
     <artifactId>hutool-all</artifactId>
     <version>5.8.4</version>
 </dependency>
```

里面有一个[ThreadUtil](https://hutool.cn/docs/#/core/%E7%BA%BF%E7%A8%8B%E5%92%8C%E5%B9%B6%E5%8F%91/%E7%BA%BF%E7%A8%8B%E5%B7%A5%E5%85%B7-ThreadUtil?id=threadutilnewexecutor "ThreadUtil")工具类

# 代码实现

```
public JSONObject getValidUrls(){
    JSONObject data = new JSONObject();
    //线程安全的集合
    CopyOnWriteArrayList<String> validAddresses = new CopyOnWriteArrayList<>();
    //需要过滤的业务数据
    List<String> addresses = jetbrainsMapper.queryAllUrl();
    //新建一个CountDownLatch，一个同步辅助类
    CountDownLatch latch = ThreadUtil.newCountDownLatch(addresses .size());
    //遍历业务数据
    for (int i = 0; i < addresses.size(); i++) {
        int finalI = i;
        //执行异步方法
        ThreadUtil.execAsync(new Runnable() {
            @Override
             public void run() {
                 //具体业务逻辑
                 String address = addresses.get(finalI);
                 if (ActivateJetBrainsUtil.checkServer(address)){
                     validAddresses.add(address);
                 }
                 //异步方法结束
                 latch.countDown();               
             }
        });  
    }

    try {
        //等待所有线程完成
        latch.await();
    } catch (InterruptedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

    data.put("服务器总数",addresses.size());
    data.put("可激活服务器个数",validAddresses.size());
    data.put("激活服务器列表",validAddresses);
    return data;
}
```

# 优化

代码比较简单，如果有优化的地方欢迎指正

