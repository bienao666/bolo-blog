title: x-ui解锁奈非
date: '2023-05-20 05:09:00'
updated: '2023-05-22 01:15:38'
tags: [科学上网]
permalink: /articles/2023/05/20/1684574695244.html
---
![image.png](https://bolo.bienao.life/image/20230520052941065.png)

# 为什么要解锁奈非

奈非和国内的爱优腾一样，是一个在全球范围内提供电影和电视节目的订阅制流媒体服务平台，平台有很多高质量的影视资源，包括美剧，好莱坞大片，动漫，纪录片等，国内用户想要观看奈非必须满足两个条件，使用能够解锁奈非的节点进行科学上网，拥有一个奈非会员账号，由于相关政策，奈非没有在国内运营，我们在国内是无法直接观看奈非，所以需要科学上网的节点能够解锁奈非

![image.png](https://bolo.bienao.life/image/20230520045559822.png)

## 检测是否解锁奈飞

```
#下载检测解锁程序
wget -O nf https://github.com/sjlleo/netflix-verify/releases/download/v3.1.0/nf_linux_amd64 && chmod +x nf

#执行
./nf

#通过代理执行
./nf -proxy socks5://127.0.0.1:30000
```

![image.png](https://bolo.bienao.life/image/20230520051215813.png)

# 安装WARP

## 安装WARP仓库GPG 密钥

```
curl https://pkg.cloudflareclient.com/pubkey.gpg | sudo gpg --yes --dearmor --output /usr/share/keyrings/cloudflare-warp-archive-keyring.gpg
```

![image.png](https://bolo.bienao.life/image/20230520050443955.png)

## 添加WARP源

```
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/cloudflare-warp-archive-keyring.gpg] https://pkg.cloudflareclient.com/ $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/cloudflare-client.list
```

![image.png](https://bolo.bienao.life/image/20230520050746502.png)

## 更新APT缓存

```
apt update
```

![image.png](https://bolo.bienao.life/image/20230520050837393.png)

## 安装WARP

```
apt install cloudflare-warp
```

![image.png](https://bolo.bienao.life/image/20230520051430222.png)

## 注册WARP

```
warp-cli register
```

![image.png](https://bolo.bienao.life/image/20230520051459699.png)

## 设置为代理模式（一定要先设置）

```
warp-cli set-mode proxy
```

![image.png](https://bolo.bienao.life/image/20230520051515404.png)

## 连接WARP

```
warp-cli connect
```

![image.png](https://bolo.bienao.life/image/20230520051533755.png)

## 检测是否解锁奈飞

```
./nf -proxy socks5://127.0.0.1:40000
```

## x-ui配置

复制下方目标，设置到x-ui面板中，保存配置，重启面板

```
{
  "api": {
    "services": [
      "HandlerService",
      "LoggerService",
      "StatsService"
    ],
    "tag": "api"
  },
  "inbounds": [
    {
      "listen": "127.0.0.1",
      "port": 62789,
      "protocol": "dokodemo-door",
      "settings": {
        "address": "127.0.0.1"
      },
      "tag": "api"
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    },
    {
      "tag": "netflix_proxy",
      "protocol": "socks",
      "settings": {
        "servers": [
          {
            "address": "127.0.0.1",
            "port": 40000
          }
        ]
      }
    },
    {
      "protocol": "blackhole",
      "settings": {},
      "tag": "blocked"
    }
  ],
  "policy": {
    "system": {
      "statsInboundDownlink": true,
      "statsInboundUplink": true
    }
  },
  "routing": {
    "rules": [
      {
        "type": "field",
        "outboundTag": "netflix_proxy",
        "domain": [
          "geosite:netflix",
          "geosite:disney"
        ]
      },
      {
        "inboundTag": [
          "api"
        ],
        "outboundTag": "api",
        "type": "field"
      },
      {
        "ip": [
          "geoip:private"
        ],
        "outboundTag": "blocked",
        "type": "field"
      },
      {
        "outboundTag": "blocked",
        "protocol": [
          "bittorrent"
        ],
        "type": "field"
      }
    ]
  },
  "stats": {}
}
```

![image.png](https://bolo.bienao.life/image/20230520052249404.png)

# 测试

![image.png](https://bolo.bienao.life/image/20230520052421369.png)

