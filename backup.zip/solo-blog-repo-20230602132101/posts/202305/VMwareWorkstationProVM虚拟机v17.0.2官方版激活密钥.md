title: VMware Workstation Pro(VM虚拟机) v17.0.2 官方版+激活密钥
date: '2023-05-30 00:23:00'
updated: '2023-05-30 00:23:00'
tags: [VM虚拟机]
permalink: /articles/2023/05/30/1685425624700.html
---
# 介绍

VMware Workstation Pro 是将多个操作系统作为虚拟机 (VM) 在单台 Linux 或 Windows PC 上运行的行业标准。为任何设备、平台或云环境构建、测试或演示软件的 IT 专业人员、开发人员和企业都可以信赖 Workstation Pro。

![image.png](https://bolo.bienao.life/image/20230530014655256.png)

# Mware Workstation Pro 17 的新功能特性

新增功能
自动启动虚拟机

现在，您可以将本地虚拟机配置为在主机引导时自动启动。

支持新的客户机操作系统

Microsoft Windows 11

Microsoft Windows Server 2022

RHEL 9

Debian 11.x

Ubuntu 22.04

全新虚拟可信平台模块 2.0

Workstation Pro 现在提供虚拟可信平台模块（版本 2.0）设备，以支持 Windows 11 以及需要 TPM 的其他操作系统。

# 客户机操作系统要求

Windows 7 或更高版本

具有 Mesa 22.0.0 和 Linux 内核 5.16.0 的 Linux

支持 WDDM 1.2

# 新的改进

新的完全或快速加密功能

现在，您可以在安全性（完全）和性能（快速）加密选项之间选择。

改进了图形支持：OPENGL 4.3

Workstation Pro 现在支持将 OpenGL 4.3 用于虚拟机。

Workstation Pro 现在支持将 WDDM（Windows 显示驱动程序模型）版本 1.2 用于虚拟机。

产品支持注意事项
用于将虚拟磁盘映射或挂载到主机系统上驱动器的选项在 Workstation Pro 中不再可用。

已知问题
在虚拟机向导中，Workstation 对 FreeBSD 操作系统的选定 ISO 映像显示的版本可能不正确

创建虚拟机时，如果选择 FreeBSD 12.x 或 13.x 操作系统的 ISO 映像，则虚拟机向导显示的 FreeBSD 操作系统版本不正确。

将操作系统类型手动设置为相应版本的 FreeBSD。

如果为虚拟机配置自动启动，则在主机引导时，虚拟机控制台可能会显示黑屏

如果为虚拟机配置自动启动功能，则在主机启动时，vmware-vmx.exe 进程将打开虚拟机电源。当主机在用户未登录到 Windows 的情况下启动时，vmware-vmx.exe 进程将在会话 0 上运行。Windows 会话 0 隔离安全性会限制虚拟机的视频渲染。这会导致虚拟机控制台上显示黑屏。

解决方法：

您可以使用以下解决方法查看虚拟机用户界面：

使用备用方法连接和查看虚拟机用户界面。例如，VNC 查看器或远程桌面查看器。

挂起虚拟机，然后在 Workstation Pro 中恢复虚拟机。

已解决的问题
在客户机虚拟机内搜索蓝牙设备时，主机上的 USBarbitrator64.exe 崩溃

尝试将蓝牙设备添加到虚拟机时，主机上的 USBArbitrator.exe 会崩溃，并且蓝牙设备无法连接到虚拟机。

这个问题已得到解决。

无法同时打开多个虚拟机

如果有多个虚拟机在运行，并且共享一个通用虚拟机目录，则无法同时打开多个此类虚拟机。

这个问题已得到解决。

对于 Fedora 64 位客户机操作系统，无法指定固件

尝试使用 Fedora 64 位客户机操作系统创建虚拟机时，新虚拟机向导中没有提供在 UEFI 和 BIOS 固件之间选择的选项。

这个问题已得到解决。

Microsoft Edge 浏览器上显示的图像不清晰

在使用 Windows 客户机操作系统的虚拟机上，Microsoft Edge 浏览器上显示的图像不清晰。

这个问题已得到解决。

安全问题
OpenSSL 已更新到 1.1.1q。

Python 已更新到 3.10.4。

Libgcrypt 已更新到 1.10.0。

zlib 已更新到 1.2.12。

Expat 已更新到 2.4.9。

# 下载

[点我下载](http://121.43.32.165:10025/d/1.%E8%BD%AF%E4%BB%B6%E5%A4%A7%E5%85%A8/%E7%94%B5%E8%84%91/%E7%B3%BB%E7%BB%9F%E7%9B%B8%E5%85%B3/%E7%B3%BB%E7%BB%9F%E5%A2%9E%E5%BC%BA/VM%E8%99%9A%E6%8B%9F%E6%9C%BA/VMware-workstation-full-17.0.0-20800274.exe)

# 激活

秘钥

```
MC60H-DWHD5-H80U9-6V85M-8280D
```

